# Moto V18 — Authentication & Security Foundation

Implemented in this build:
- Firebase Authentication dependency.
- Email/password sign-in and account creation screen.
- Auth state gate before passenger/driver screens.
- Sign-out capability available through the auth service.

Important production security:
- Enable Email/Password provider in Firebase Authentication before testing sign-in.
- Admin access must use a server-verified admin role/custom claim; hiding an admin button in the app is not security.
- Realtime Database rules must be locked down before launch.
- iOS Firebase configuration is still account-specific and must be added from the Firebase console.
