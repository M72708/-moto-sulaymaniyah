# Moto V28 — Release Preflight

تم تجهيز نسخة ما قبل الإطلاق.

## تم التحقق منه
- وجود مشروع Flutter و`pubspec.yaml`.
- وجود Firebase Android config: `android/app/google-services.json`.
- وجود كود تسجيل الدخول، الراكب، السائق، الأدمن، الرحلات المباشرة والتسعير.
- وجود قواعد Firebase V27 ومسار إعداد أول مدير.
- رفع رقم النسخة إلى 0.3.0+3.

## مهم
هذه البيئة لا تحتوي على Flutter SDK/Android SDK/Xcode، لذلك لم يتم إنشاء APK أو IPA ولم يتم الادعاء باختبار تشغيل فعلي على جهاز.

## قبل الإطلاق
1. تشغيل `flutter pub get`.
2. تشغيل `flutter analyze`.
3. تشغيل التطبيق على Android واختبار الرحلة كاملة.
4. إعداد Firebase iOS وإضافة `GoogleService-Info.plist`.
5. اختبار iPhone الحقيقي.
6. تطبيق قواعد Firebase النهائية في المشروع قبل استقبال مستخدمين حقيقيين.
