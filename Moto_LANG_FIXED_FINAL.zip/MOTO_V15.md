# Moto V15 — Full Trip Flow

Trip-flow stage:
- Passenger creates a ride request.
- Ride carries pickup, destination, estimated fare, and status.
- Driver can see searching rides and accept one.
- Accepted ride stores driver ID.
- Driver location can be published while the ride is active.
- Ride status flow: searching -> accepted -> in_progress -> completed.
- Passenger can observe the accepted ride and driver location.
- Cancellation/rejection remains separate from completed trips.

Before production:
- Firebase Authentication and secure Realtime Database rules must be enabled.
- Real iOS Firebase configuration is still account-specific and is not fabricated here.
- Maps/routing and GPS permissions need testing on physical devices.
