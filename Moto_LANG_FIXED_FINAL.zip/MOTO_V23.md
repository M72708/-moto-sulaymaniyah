# MOTO V23

Implemented passenger account and trip history features.
- Passenger profile: name + phone, saved to Firebase users/{uid}.
- Passenger trip history reads rides filtered by passengerId.
- Completed ride supports 1–5 star rating saved to the ride.
- Passenger app bar now opens account and history.

Note: Firebase Realtime Database rules must allow authenticated users to read/write only their own profile and rides in production.
