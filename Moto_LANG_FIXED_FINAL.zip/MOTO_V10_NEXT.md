# Moto V10 — next integration stage

- Android Firebase configuration is retained from the previous version.
- Realtime Database ride flow scaffold is retained.
- iOS Firebase configuration remains account-specific: add `ios/Runner/GoogleService-Info.plist`
  downloaded from the Moto Sulaymaniyah Firebase project.
- Do not make Realtime Database public. Keep locked/authenticated rules until authentication is wired.
- Next implementation target: connect passenger request -> Firebase `rides/<rideId>` and driver stream/acceptance,
  then wire live driver location and trip status into the UI.
