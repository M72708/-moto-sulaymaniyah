# Moto V17 — Admin Dashboard Stage

Admin dashboard structure:
- Driver management: list, verification status, online/offline status.
- Passenger management.
- Ride management: searching, accepted, in progress, completed, cancelled.
- Pricing configuration.
- Complaints/support records.
- Basic operational statistics.

Production requirements:
- Admin authentication and role-based access must be enforced server-side.
- Realtime Database rules must prevent normal users from reading/writing admin-only data.
- Pricing changes should be logged.
