import 'dart:async';
import 'dart:math' as math;

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import 'routing_service.dart';
import 'firebase_service.dart';
import 'auth_service.dart';
import 'admin_dashboard.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Object? firebaseError;
  try {
    await Firebase.initializeApp();
  } catch (e) {
    firebaseError = e;
  }
  runApp(MotoApp(firebaseError: firebaseError));
}

const _yellow = Color(0xFFFFC400);
const _sulaymaniyah = LatLng(35.5613, 45.4376);

class MotoApp extends StatelessWidget {
  final Object? firebaseError;
  const MotoApp({super.key, this.firebaseError});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'موتو',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        colorScheme: ColorScheme.fromSeed(seedColor: _yellow),
        scaffoldBackgroundColor: const Color(0xFFF7F8FA),
      ),
      home: firebaseError != null
          ? FirebaseDiagnosticScreen(error: firebaseError!)
          : const AuthGate(),
    );
  }
}

class FirebaseDiagnosticScreen extends StatelessWidget {
  final Object error;
  const FirebaseDiagnosticScreen({super.key, required this.error});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('موتو')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('التطبيق اشتغل، لكن Firebase لم يبدأ.', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            const Text('هذا خطأ تشخيصي حتى نعرف سبب المشكلة.'),
            const SizedBox(height: 16),
            SelectableText(error.toString()),
          ],
        ),
      ),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        return snapshot.data == null ? const LoginScreen() : const RoleScreen();
      },
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _auth = MotoAuthService();
  bool _loading = false;
  bool _create = false;

  Future<void> _submit() async {
    final email = _email.text.trim();
    final password = _password.text;
    if (email.isEmpty || password.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب إيميل وكلمة مرور 6 أحرف أو أكثر.')));
      return;
    }
    setState(() => _loading = true);
    try {
      if (_create) {
        await _auth.signUp(email, password);
      } else {
        await _auth.signIn(email, password);
      }
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      final message = switch (e.code) {
        'email-already-in-use' => 'هذا الإيميل مستخدم مسبقاً.',
        'invalid-credential' => 'الإيميل أو كلمة المرور غير صحيحة.',
        'weak-password' => 'كلمة المرور ضعيفة.',
        'invalid-email' => 'الإيميل غير صحيح.',
        _ => 'تعذر تسجيل الدخول حالياً.',
      };
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() { _email.dispose(); _password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('تسجيل الدخول')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.two_wheeler, size: 70),
            const SizedBox(height: 16),
            Text(_create ? 'إنشاء حساب موتو' : 'الدخول إلى موتو', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'الإيميل', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: _password, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور', border: OutlineInputBorder())),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _loading ? null : _submit, child: Text(_loading ? 'انتظر...' : (_create ? 'إنشاء الحساب' : 'دخول')))),
            TextButton(onPressed: _loading ? null : () => setState(() => _create = !_create), child: Text(_create ? 'عندي حساب — دخول' : 'إنشاء حساب جديد')),
          ],
        ),
      ),
    ),
  );
}

class RoleScreen extends StatelessWidget {
  const RoleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Spacer(),
                Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(color: _yellow, borderRadius: BorderRadius.circular(30)),
                  child: const Center(child: Icon(Icons.two_wheeler, size: 64, color: Colors.black)),
                ),
                const SizedBox(height: 18),
                const Text('موتو', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                const Text('نقل بالماطور — أسرع وأوفر', style: TextStyle(fontSize: 17, color: Colors.black54)),
                const Spacer(),
                _RoleButton(icon: Icons.person, title: 'أنا راكب', subtitle: 'أريد طلب رحلة', onTap: () async { final u = FirebaseAuth.instance.currentUser; if (u != null) { try { await MotoFirebaseService().saveUserProfile(uid: u.uid, email: u.email ?? '', role: 'passenger'); } catch (_) {} } if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const PassengerHome())); }),
                const SizedBox(height: 12),
                _RoleButton(icon: Icons.two_wheeler, title: 'أنا سائق', subtitle: 'أريد استقبال الرحلات', onTap: () { if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const DriverRegistrationScreen())); }),
                const SizedBox(height: 20),
                OutlinedButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminLoginScreen())),
                  icon: const Icon(Icons.admin_panel_settings),
                  label: const Text('دخول الإدارة'),
                ),
                const SizedBox(height: 12),
                const Text('نسخة تجريبية — خريطة + GPS + مسار حقيقي + ETA', style: TextStyle(color: Colors.black45)),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RoleButton extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _RoleButton({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        child: FilledButton(
          style: FilledButton.styleFrom(
            backgroundColor: Colors.white,
            foregroundColor: Colors.black,
            elevation: 1,
            padding: const EdgeInsets.all(18),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFE5E7EB))),
          ),
          onPressed: onTap,
          child: Row(
            children: [
              CircleAvatar(backgroundColor: _yellow, foregroundColor: Colors.black, child: Icon(icon)),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text(subtitle, style: const TextStyle(color: Colors.black54))])),
              const Icon(Icons.arrow_back_ios_new, size: 18),
            ],
          ),
        ),
      );
}


class RideRequest {
  RideRequest({required this.id, required this.origin, required this.destination, required this.fareIqd, required this.distanceKm, required this.etaMinutes});
  final String id;
  final LatLng origin;
  final LatLng destination;
  final int fareIqd;
  final double distanceKm;
  final int etaMinutes;
  String status = 'searching'; // searching, accepted, started, finished, cancelled
  LatLng? driverLocation;
  String driverName = 'علي محمد';
  String driverBike = 'Honda 150 • 22-2567';
}

class RideHub {
  RideHub._();
  static final RideHub instance = RideHub._();
  final ValueNotifier<RideRequest?> activeRide = ValueNotifier<RideRequest?>(null);

  void createRide(RideRequest ride) => activeRide.value = ride;
  void acceptRide(LatLng driverLocation) {
    final ride = activeRide.value;
    if (ride == null) return;
    ride.status = 'accepted';
    ride.driverLocation = driverLocation;
    activeRide.value = ride;
  }
  void updateDriverLocation(LatLng point) {
    final ride = activeRide.value;
    if (ride == null) return;
    ride.driverLocation = point;
    activeRide.value = ride;
  }
  void startRide() {
    final ride = activeRide.value;
    if (ride == null) return;
    ride.status = 'started';
    activeRide.value = ride;
  }
  void finishRide() {
    final ride = activeRide.value;
    if (ride == null) return;
    ride.status = 'finished';
    activeRide.value = ride;
  }
  void clear() => activeRide.value = null;
}

class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});
  @override
  State<PassengerHome> createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  final MapController _mapController = MapController();
  final RoutingService _routing = RoutingService();
  LatLng _center = _sulaymaniyah;
  LatLng? _myLocation;
  LatLng? _destination;
  RouteResult? _route;
  bool _locating = false;
  final MotoFirebaseService _firebase = MotoFirebaseService();
  StreamSubscription<DatabaseEvent>? _firebaseRideSub;
  StreamSubscription<DatabaseEvent>? _driverLocationSub;
  String? _firebaseRideId;
  String get _passengerId => FirebaseAuth.instance.currentUser?.uid ?? 'anonymous';
  bool _searching = false;
  bool _tripStarted = false;
  bool _tripFinished = false;
  bool _selectingDestination = false;
  bool _routingLoading = false;
  double _baseFare = 1000;
  double _perKm = 500;
  StreamSubscription<DatabaseEvent>? _pricingSub;

  @override
  void initState() { super.initState(); RideHub.instance.activeRide.addListener(_onRideChanged); _loadPricing(); _pricingSub = _firebase.pricingStream().listen((event) { final v = event.snapshot.value; if (v is Map) { final b = v['baseFare']; final k = v['perKm']; if (mounted) setState(() { if (b is num) _baseFare = b.toDouble(); if (k is num) _perKm = k.toDouble(); }); } }); }
  @override
  void dispose() { RideHub.instance.activeRide.removeListener(_onRideChanged); _firebaseRideSub?.cancel(); _driverLocationSub?.cancel(); _pricingSub?.cancel(); super.dispose(); }
  void _onRideChanged() { final ride = RideHub.instance.activeRide.value; if (!mounted || ride == null) return; setState(() { _tripStarted = ride.status == 'started'; _searching = ride.status == 'searching'; if (ride.status == 'finished') _tripFinished = true; }); }

  LatLng get _origin => _myLocation ?? _center;
  double get _distanceKm => _route?.distanceKm ?? 0;
  int get _fareIqd {
    if (_route == null) return 0;
    final raw = _baseFare + (_distanceKm * _perKm);
    final rounded = ((raw / 250).round() * 250).clamp(_baseFare, 100000);
    return rounded.round();
  }

  Future<void> _loadPricing() async {
    try {
      final snap = await _firebase.db.ref('settings/pricing').get();
      final v = snap.value;
      if (v is Map && mounted) {
        setState(() {
          if (v['baseFare'] is num) _baseFare = (v['baseFare'] as num).toDouble();
          if (v['perKm'] is num) _perKm = (v['perKm'] as num).toDouble();
        });
      }
    } catch (_) {}
  }

  Future<void> _locateMe() async {
    setState(() => _locating = true);
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showMessage('فعّل خدمة الموقع (GPS) من إعدادات الهاتف.');
        return;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        _showMessage('لازم تسمح للتطبيق باستخدام الموقع.');
        return;
      }
      final position = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      final point = LatLng(position.latitude, position.longitude);
      setState(() {
        _myLocation = point;
        _center = point;
      });
      _mapController.move(point, 15.5);
      final ride = RideHub.instance.activeRide.value;
      if (ride != null && (ride.status == 'accepted' || ride.status == 'started')) {
        RideHub.instance.updateDriverLocation(point);
        if (_firebaseRideId != null) { try { await _firebase.updateRideDriverLocation(_firebaseRideId!, point.latitude, point.longitude); } catch (_) {} }
      }
      if (_destination != null) await _loadRoute(point, _destination!);
    } catch (_) {
      _showMessage('تعذر تحديد موقعك حالياً.');
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _loadRoute(LatLng from, LatLng to) async {
    setState(() {
      _routingLoading = true;
      _route = null;
    });
    try {
      final result = await _routing.getRoute(from, to);
      if (!mounted) return;
      setState(() => _route = result);
      _fitRoute(result.points);
    } catch (_) {
      _showMessage('تعذر حساب المسار. تأكد من الإنترنت وحاول مرة ثانية.');
    } finally {
      if (mounted) setState(() => _routingLoading = false);
    }
  }

  void _fitRoute(List<LatLng> points) {
    if (points.length < 2) return;
    final lats = points.map((p) => p.latitude).toList();
    final lons = points.map((p) => p.longitude).toList();
    final bounds = LatLngBounds(LatLng(lats.reduce(math.min), lons.reduce(math.min)), LatLng(lats.reduce(math.max), lons.reduce(math.max)));
    _mapController.fitCamera(CameraFit.bounds(bounds: bounds, padding: const EdgeInsets.fromLTRB(70, 160, 70, 300)));
  }

  Future<void> _onMapTap(TapPosition _, LatLng point) async {
    if (!_selectingDestination) return;
    setState(() {
      _destination = point;
      _selectingDestination = false;
    });
    await _loadRoute(_origin, point);
    _showMessage('تم تحديد الوجهة وحساب المسار حسب الشوارع.');
  }

  void _showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _requestRide() async {
    if (_destination == null || _route == null) {
      _showMessage('حدد الوجهة وانتظر ظهور المسافة أولاً.');
      return;
    }
    setState(() => _searching = true);
    try {
      final rideId = await _firebase.createRide(
        passengerId: _passengerId,
        pickupLat: _origin.latitude,
        pickupLng: _origin.longitude,
        destinationLat: _destination!.latitude,
        destinationLng: _destination!.longitude,
        fare: _fareIqd.toDouble(),
        distanceKm: _distanceKm,
      );
      _firebaseRideId = rideId;
      await _firebaseRideSub?.cancel();
      _firebaseRideSub = _firebase.rideStream(rideId).listen((event) async {
        final data = event.snapshot.value;
        if (data is! Map) return;
        final status = (data['status'] ?? 'searching').toString();
        final ride = RideHub.instance.activeRide.value ?? RideRequest(
          id: rideId,
          origin: _origin,
          destination: _destination!,
          fareIqd: _fareIqd,
          distanceKm: _distanceKm,
          etaMinutes: _route?.etaMinutes ?? 0,
        );
        ride.status = status == 'in_progress' ? 'started' : (status == 'completed' ? 'finished' : status);
        final driverId = data['driverId']?.toString();
        if (driverId != null && driverId.isNotEmpty) {
          try {
            final ds = await _firebase.drivers.child(driverId).get();
            final dv = ds.value;
            if (dv is Map) {
              ride.driverName = (dv['name'] ?? dv['email'] ?? ride.driverName).toString();
              ride.driverBike = (dv['bike'] ?? ride.driverBike).toString();
            }
          } catch (_) {}
        }
        final loc = data['driverLocation'];
        if (loc is Map && loc['lat'] != null && loc['lng'] != null) {
          ride.driverLocation = LatLng((loc['lat'] as num).toDouble(), (loc['lng'] as num).toDouble());
          if (mounted && (status == 'accepted' || status == 'in_progress')) {
            _mapController.move(ride.driverLocation!, 15.5);
          }
        }
        RideHub.instance.createRide(ride);
        if (mounted && status == 'accepted') _showMessage('تم قبول الرحلة من السائق 🏍️');
      });
      final localRide = RideRequest(id: rideId, origin: _origin, destination: _destination!, fareIqd: _fareIqd, distanceKm: _distanceKm, etaMinutes: _route!.etaMinutes);
      RideHub.instance.createRide(localRide);
      _showMessage('تم إرسال الطلب إلى السائقين القريبين.');
    } catch (_) {
      _showMessage('تعذر إرسال الطلب إلى Firebase. تأكد من إعداد Firebase وقواعد قاعدة البيانات.');
      setState(() => _searching = false);
    }
  }

  Future<void> _resetRide() async {
    if (_firebaseRideId != null) {
      try { await _firebase.cancelRide(_firebaseRideId!); } catch (_) {}
    }
    await _firebaseRideSub?.cancel();
    _firebaseRideId = null;
    RideHub.instance.clear();
    setState(() {
      _destination = null;
      _route = null;
      _searching = false;
      _tripStarted = false;
      _tripFinished = false;
      _selectingDestination = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('موتو'), actions: [IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PassengerAccountScreen())), icon: const Icon(Icons.person_outline)), IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PassengerHistoryScreen())), icon: const Icon(Icons.history)), IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)), IconButton(onPressed: () async { await MotoAuthService().signOut(); if (context.mounted) Navigator.popUntil(context, (r) => r.isFirst); }, icon: const Icon(Icons.logout))]),
        body: Stack(
          children: [
            _RealMap(
              mapController: _mapController,
              center: _center,
              userLocation: _myLocation,
              destination: _destination,
              route: _route,
              onTap: _onMapTap,
              selectingDestination: _selectingDestination,
              extraMarkers: RideHub.instance.activeRide.value?.driverLocation == null
                  ? const []
                  : [_MapPoint(RideHub.instance.activeRide.value!.driverLocation!, Icons.two_wheeler, Colors.black)],
            ),
            Positioned(
              top: 16,
              right: 16,
              left: 16,
              child: Card(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13), child: Row(children: [
                Icon(_selectingDestination ? Icons.touch_app : Icons.map, color: _selectingDestination ? Colors.green : Colors.black54),
                const SizedBox(width: 10),
                Expanded(child: Text(_selectingDestination ? 'اضغط على الخريطة لتحديد الوجهة' : (_destination == null ? 'حدد وجهتك من الخريطة' : (_routingLoading ? 'جاري حساب الطريق...' : 'تم حساب الطريق')) , style: const TextStyle(fontSize: 16, color: Colors.black54))),
              ]))),
            ),
            Positioned(top: 84, right: 16, child: FloatingActionButton.small(heroTag: 'gps-passenger', onPressed: _locating ? null : _locateMe, backgroundColor: Colors.white, foregroundColor: Colors.black, child: _locating ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.my_location))),
            if (_destination != null && !_tripStarted && !_tripFinished)
              Positioned(top: 84, left: 16, child: FloatingActionButton.small(heroTag: 'clear-destination', onPressed: () => setState(() { _destination = null; _route = null; }), backgroundColor: Colors.white, foregroundColor: Colors.red, child: const Icon(Icons.close))),
            if (_tripStarted && !_tripFinished)
              Positioned(left: 16, right: 16, bottom: 20, child: _TripCard(onFinish: () => setState(() => _tripFinished = true), fare: _fareIqd, etaMinutes: _route?.etaMinutes ?? 0))
            else if (!_tripFinished)
              Positioned(left: 16, right: 16, bottom: 20, child: _NewRideCard(selecting: _selectingDestination, searching: _searching, routingLoading: _routingLoading, destination: _destination, distanceKm: _distanceKm, fareIqd: _fareIqd, etaMinutes: _route?.etaMinutes ?? 0, onSelectDestination: () => setState(() => _selectingDestination = true), onRequest: _requestRide))
            else
              Positioned.fill(child: Center(child: Card(margin: const EdgeInsets.all(30), child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.check_circle, size: 70, color: Colors.green),
                const SizedBox(height: 12),
                const Text('وصلت بالسلامة!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('المبلغ النهائي: ${_formatIqd(_fareIqd)} د.ع'),
                const SizedBox(height: 18),
                Column(children: [
                  const Text('قيّم السائق'),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      5,
                      (i) => IconButton(
                        onPressed: () async {
                          if (_firebaseRideId != null) {
                            try {
                              await _firebase.rateRide(
                                rideId: _firebaseRideId!,
                                passengerId: _passengerId,
                                rating: i + 1,
                              );
                              _showMessage('تم حفظ تقييمك ⭐');
                            } catch (_) {}
                          }
                        },
                        icon: const Icon(Icons.star, color: _yellow, size: 32),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  FilledButton(onPressed: _resetRide, child: const Text('رحلة جديدة')),
                ]),
              ])))))
          ],
        ),
      ),
    );
  }
}


class PassengerAccountScreen extends StatefulWidget {
  const PassengerAccountScreen({super.key});
  @override State<PassengerAccountScreen> createState() => _PassengerAccountScreenState();
}

class _PassengerAccountScreenState extends State<PassengerAccountScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _firebase = MotoFirebaseService();
  bool _loading = true;
  String _email = '';
  String get _uid => FirebaseAuth.instance.currentUser?.uid ?? '';

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    if (_uid.isEmpty) return;
    try {
      final snap = await _firebase.users.child(_uid).get();
      final v = snap.value;
      if (v is Map) { _name.text = (v['name'] ?? '').toString(); _phone.text = (v['phone'] ?? '').toString(); _email = (v['email'] ?? FirebaseAuth.instance.currentUser?.email ?? '').toString(); }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }
  Future<void> _save() async {
    if (_uid.isEmpty || _phone.text.trim().isEmpty) return;
    try { await _firebase.savePassengerProfile(uid: _uid, email: _email, name: _name.text.trim(), phone: _phone.text.trim()); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ بياناتك ✅'))); } catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر الحفظ. تأكد من Firebase.'))); }
  }
  @override Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(appBar: AppBar(title: const Text('حسابي')), body: _loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(20), children: [
    const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 44)), const SizedBox(height: 20),
    TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم الكامل', prefixIcon: Icon(Icons.person), border: OutlineInputBorder())), const SizedBox(height: 14),
    TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف', prefixIcon: Icon(Icons.phone), border: OutlineInputBorder())), const SizedBox(height: 14),
    Text('البريد: $_email', style: const TextStyle(color: Colors.black54)), const SizedBox(height: 20),
    FilledButton(onPressed: _save, child: const Text('حفظ البيانات')),
  ])));
}

class PassengerHistoryScreen extends StatelessWidget {
  const PassengerHistoryScreen({super.key});
  @override Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
    final firebase = MotoFirebaseService();
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(appBar: AppBar(title: const Text('سجل الرحلات')), body: StreamBuilder<DatabaseEvent>(stream: firebase.passengerRidesStream(uid), builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      final raw = snap.data?.snapshot.value;
      if (raw is! Map || raw.isEmpty) return const Center(child: Text('ما عندك رحلات سابقة بعد.'));
      final rows = <Map<String, dynamic>>[];
      raw.forEach((key, value) { if (value is Map) { rows.add({'id': key.toString(), ...Map<String, dynamic>.from(value)}); } });
      rows.sort((a,b) => ((b['createdAt'] ?? 0) as num).compareTo((a['createdAt'] ?? 0) as num));
      return ListView.separated(padding: const EdgeInsets.all(12), itemCount: rows.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) {
        final r = rows[i]; final status = (r['status'] ?? '—').toString(); final fare = ((r['fare'] ?? 0) as num).round(); final rating = r['passengerRating'] ?? r['rating'];
        return Card(child: ListTile(leading: CircleAvatar(child: Icon(status == 'completed' ? Icons.check : Icons.two_wheeler)), title: Text('${_formatIqd(fare)} د.ع'), subtitle: Text('الحالة: $status • المسافة: ${((r['distanceKm'] ?? 0) as num).toStringAsFixed(1)} كم${rating == null ? '' : ' • التقييم: $rating/5'}'), trailing: const Icon(Icons.chevron_left)));
      });
    })));
  }
}


class DriverRegistrationScreen extends StatefulWidget {
  const DriverRegistrationScreen({super.key});
  @override State<DriverRegistrationScreen> createState() => _DriverRegistrationScreenState();
}

class _DriverRegistrationScreenState extends State<DriverRegistrationScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _bike = TextEditingController();
  final _plate = TextEditingController();
  final _firebase = MotoFirebaseService();
  bool _loading = true;
  bool _saving = false;
  bool _approved = false;
  bool _blocked = false;
  String _status = 'pending';

  String get _uid => FirebaseAuth.instance.currentUser?.uid ?? '';
  String get _email => FirebaseAuth.instance.currentUser?.email ?? '';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      if (_uid.isEmpty) return;
      final snap = await _firebase.drivers.child(_uid).get();
      final v = snap.value;
      if (v is Map) {
        final d = Map<String, dynamic>.from(v);
        _name.text = (d['name'] ?? '').toString();
        _phone.text = (d['phone'] ?? '').toString();
        _bike.text = (d['bike'] ?? '').toString();
        _plate.text = (d['plate'] ?? '').toString();
        _approved = d['approved'] == true;
        _blocked = d['blocked'] == true;
        _status = (d['applicationStatus'] ?? (_approved ? 'approved' : 'pending')).toString();
      }
    } finally { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _submit() async {
    if (_name.text.trim().isEmpty || _phone.text.trim().isEmpty || _bike.text.trim().isEmpty || _plate.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('كمل الاسم ورقم الهاتف ونوع الماطور ورقم اللوحة.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await _firebase.submitDriverApplication(uid: _uid, email: _email, name: _name.text.trim(), phone: _phone.text.trim(), bike: _bike.text.trim(), plate: _plate.text.trim());
      if (mounted) setState(() { _status = 'pending'; _approved = false; _blocked = false; });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرسال بياناتك للإدارة للموافقة.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر حفظ البيانات. تأكد من اتصال Firebase.')));
    } finally { if (mounted) setState(() => _saving = false); }
  }

  @override void dispose() { _name.dispose(); _phone.dispose(); _bike.dispose(); _plate.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(title: const Text('تسجيل بيانات السائق')),
    body: _loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(20), children: [
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        const Icon(Icons.two_wheeler, size: 54), const SizedBox(height: 8),
        const Text('بيانات السائق', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6), const Text('بعد الإرسال، الإدارة تراجع البيانات قبل تفعيل استقبال الرحلات.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
      ]))),
      const SizedBox(height: 14),
      if (_blocked) Card(color: Colors.red.shade50, child: const ListTile(leading: Icon(Icons.block, color: Colors.red), title: Text('الحساب محظور'), subtitle: Text('راجع الإدارة قبل محاولة التفعيل.')))
      else if (_approved) Card(color: Colors.green.shade50, child: ListTile(leading: const Icon(Icons.verified, color: Colors.green), title: const Text('تمت الموافقة على حسابك'), subtitle: const Text('تقدر تدخل وتستقبل الرحلات.'), trailing: FilledButton(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const DriverHome())), child: const Text('دخول'))))
      else Card(color: Colors.orange.shade50, child: ListTile(leading: const Icon(Icons.hourglass_top), title: const Text('بانتظار موافقة الإدارة'), subtitle: Text(_status == 'pending' ? 'بياناتك قيد المراجعة.' : 'أرسل بياناتك حتى تبدأ المراجعة.'))),
      const SizedBox(height: 14),
      TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم الكامل', border: OutlineInputBorder(), prefixIcon: Icon(Icons.person))),
      const SizedBox(height: 12), TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف', border: OutlineInputBorder(), prefixIcon: Icon(Icons.phone))),
      const SizedBox(height: 12), TextField(controller: _bike, decoration: const InputDecoration(labelText: 'نوع الماطور (مثلاً Honda 150)', border: OutlineInputBorder(), prefixIcon: Icon(Icons.two_wheeler))),
      const SizedBox(height: 12), TextField(controller: _plate, decoration: const InputDecoration(labelText: 'رقم اللوحة', border: OutlineInputBorder(), prefixIcon: Icon(Icons.confirmation_number))),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: _saving ? null : _submit, icon: const Icon(Icons.send), label: Text(_saving ? 'جاري الحفظ...' : 'إرسال للموافقة')),
      const SizedBox(height: 10),
      if (_approved) OutlinedButton.icon(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const DriverHome())), icon: const Icon(Icons.login), label: const Text('الدخول للسائق')),
    ]),
  ));
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final MapController _mapController = MapController();
  LatLng _center = _sulaymaniyah;
  LatLng? _myLocation;
  bool online = false;
  bool hasRequest = false;
  bool trip = false;
  LatLng? _passengerLocation;
  LatLng? _destination;
  bool _locating = false;
  final MotoFirebaseService _firebase = MotoFirebaseService();
  StreamSubscription<DatabaseEvent>? _requestsSub;
  StreamSubscription<DatabaseEvent>? _driverRideSub;
  StreamSubscription<DatabaseEvent>? _driverProfileSub;
  StreamSubscription<DatabaseEvent>? _driverRidesSub;
  StreamSubscription<Position>? _positionSub;
  String? _activeFirebaseRideId;
  bool _approved = false;
  bool _blocked = false;
  double _earnings = 0;
  int _completedTrips = 0;
  final Set<String> _ignoredRideIds = <String>{};
  String get _driverId => FirebaseAuth.instance.currentUser?.uid ?? 'anonymous';

  @override
  void initState() {
    super.initState();
    RideHub.instance.activeRide.addListener(_onRideChanged);
    _listenDriverProfile();
    _listenDriverEarnings();
    _listenForFirebaseRequests();
    _setOnlineState(false);
  }
  @override
  void dispose() {
    RideHub.instance.activeRide.removeListener(_onRideChanged);
    _requestsSub?.cancel();
    _driverRideSub?.cancel();
    _driverProfileSub?.cancel();
    _driverRidesSub?.cancel();
    _positionSub?.cancel();
    super.dispose();
  }

  void _listenDriverProfile() {
    _driverProfileSub = _firebase.driverStream(_driverId).listen((event) {
      final raw = event.snapshot.value;
      final data = raw is Map ? Map<String, dynamic>.from(raw) : <String, dynamic>{};
      final approved = data['approved'] == true;
      final blocked = data['blocked'] == true;
      if (!mounted) return;
      setState(() { _approved = approved; _blocked = blocked; });
      if (blocked || !approved) {
        if (online) { setState(() => online = false); _positionSub?.cancel(); _positionSub = null; }
        _setOnlineState(false);
      }
    });
  }

  void _listenDriverEarnings() {
    _driverRidesSub = _firebase.driverRidesStream(_driverId).listen((event) {
      final raw = event.snapshot.value;
      double total = 0; int count = 0;
      if (raw is Map) {
        for (final value in raw.values) {
          if (value is Map && value['status'] == 'completed') {
            final fare = value['fare'];
            if (fare is num) total += fare.toDouble();
            count++;
          }
        }
      }
      if (mounted) setState(() { _earnings = total; _completedTrips = count; });
    });
  }

  void _listenForFirebaseRequests() {
    _requestsSub = _firebase.searchingRidesStream().listen((event) {
      final raw = event.snapshot.value;
      if (raw is! Map) return;
      final entries = raw.entries.toList();
      if (entries.isEmpty || !online || !_approved || _blocked) return;
      final first = entries.first;
      final id = first.key.toString();
      if (_ignoredRideIds.contains(id)) return;
      final data = first.value;
      if (data is! Map) return;
      final pickup = data['pickup'];
      final destination = data['destination'];
      if (pickup is! Map || destination is! Map) return;
      final origin = LatLng((pickup['lat'] as num).toDouble(), (pickup['lng'] as num).toDouble());
      final dest = LatLng((destination['lat'] as num).toDouble(), (destination['lng'] as num).toDouble());
      final ride = RideRequest(
        id: id, origin: origin, destination: dest,
        fareIqd: ((data['fare'] as num?)?.toDouble() ?? 0).round(),
        distanceKm: ((data['distanceKm'] as num?)?.toDouble() ?? 0), etaMinutes: 0,
      );
      _activeFirebaseRideId = id;
      RideHub.instance.createRide(ride);
    });
  }
  void _onRideChanged() { final ride = RideHub.instance.activeRide.value; if (!mounted) return; setState(() { hasRequest = ride != null && ride.status == 'searching'; trip = ride?.status == 'accepted' || ride?.status == 'started'; _passengerLocation = ride?.origin; _destination = ride?.destination; }); }

  Future<void> _setOnlineState(bool value) async {
    if (value && (!_approved || _blocked)) return;
    try {
      await _firebase.setDriverOnline(_driverId, online: value, lat: _myLocation?.latitude, lng: _myLocation?.longitude);
    } catch (_) {}
  }

  Future<void> _startLiveLocation() async {
    await _positionSub?.cancel();
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return;
    _positionSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 10),
    ).listen((p) async {
      final point = LatLng(p.latitude, p.longitude);
      if (!mounted) return;
      setState(() { _myLocation = point; _center = point; });
      try {
        await _firebase.updateDriverLocation(_driverId, p.latitude, p.longitude);
        final rideId = _activeFirebaseRideId;
        if (rideId != null && (RideHub.instance.activeRide.value?.status == 'accepted' || RideHub.instance.activeRide.value?.status == 'started')) {
          await _firebase.updateRideDriverLocation(rideId, p.latitude, p.longitude);
        }
      } catch (_) {}
    });
  }

  Future<void> _locateMe() async {
    setState(() => _locating = true);
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) throw Exception();
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) throw Exception();
      final p = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      final point = LatLng(p.latitude, p.longitude);
      setState(() { _myLocation = point; _center = point; });
      _mapController.move(point, 15.5);
      final ride = RideHub.instance.activeRide.value;
      if (ride != null && (ride.status == 'accepted' || ride.status == 'started')) {
        RideHub.instance.updateDriverLocation(point);
        final id = _activeFirebaseRideId;
        if (id != null) {
          try { await _firebase.updateRideDriverLocation(id, point.latitude, point.longitude); } catch (_) {}
        }
      }
      try { await _firebase.updateDriverLocation(_driverId, point.latitude, point.longitude); } catch (_) {}
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر تحديد موقع السائق.')));
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _showDriverRatingDialog(String rideId) async {
    int selected = 0;
    await showDialog<void>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(
      title: const Text('قيّم الراكب'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('كيف كانت تجربتك مع الراكب؟'),
        const SizedBox(height: 12),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(5, (i) => IconButton(
          onPressed: () => setLocal(() => selected = i + 1),
          icon: Icon(Icons.star, size: 34, color: i < selected ? _yellow : Colors.grey),
        ))),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('لاحقاً')),
        FilledButton(onPressed: selected == 0 ? null : () async {
          try { await _firebase.rateRideByDriver(rideId: rideId, driverId: _driverId, rating: selected); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ تقييم الراكب ⭐'))); } catch (_) {}
          if (dialogContext.mounted) Navigator.pop(dialogContext);
        }, child: const Text('حفظ')),
      ],
    )));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('موتو — السائق'), actions: [IconButton(onPressed: () async { await MotoAuthService().signOut(); if (context.mounted) Navigator.popUntil(context, (r) => r.isFirst); }, icon: const Icon(Icons.logout))]),
        body: Stack(children: [
          _RealMap(mapController: _mapController, center: _center, userLocation: _myLocation, destination: _destination, extraMarkers: _passengerLocation == null ? const [] : [_MapPoint(_passengerLocation!, Icons.person_pin_circle, Colors.green)]),
          Positioned(top: 16, left: 16, right: 16, child: Card(child: SwitchListTile(value: online, onChanged: (!_approved || _blocked) ? null : (v) async {
            setState(() => online = v);
            if (v) { await _startLiveLocation(); } else { await _positionSub?.cancel(); _positionSub = null; }
            try { await _firebase.setDriverOnline(_driverId, online: v, lat: _myLocation?.latitude, lng: _myLocation?.longitude); } catch (_) {}
          }, title: Text(online ? 'متاح للعمل' : 'غير متاح'), subtitle: const Text('استقبال طلبات الرحلات القريبة'), secondary: Icon(Icons.circle, color: online ? Colors.green : Colors.grey)))),
          Positioned(top: 92, right: 16, child: FloatingActionButton.small(heroTag: 'gps-driver', onPressed: _locating ? null : _locateMe, backgroundColor: Colors.white, foregroundColor: Colors.black, child: _locating ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.my_location))),
          Positioned(top: 104, left: 16, child: Card(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('أرباحك: ${_earnings.toStringAsFixed(0)} د.ع', style: const TextStyle(fontWeight: FontWeight.bold)),
            Text('رحلات مكتملة: $_completedTrips', style: const TextStyle(fontSize: 12)),
          ])))), 
          if (!_approved || _blocked) Positioned(bottom: 20, left: 16, right: 16, child: Card(color: _blocked ? Colors.red.shade50 : Colors.orange.shade50, child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
            Icon(_blocked ? Icons.block : Icons.hourglass_top, size: 42, color: _blocked ? Colors.red : Colors.orange),
            const SizedBox(height: 8),
            Text(_blocked ? 'حسابك محظور' : 'بانتظار موافقة الإدارة', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            Text(_blocked ? 'لا يمكن استقبال الرحلات حالياً.' : 'بعد الموافقة تقدر تتحول إلى متاح للعمل.'),
          ])))), 
          if (online && hasRequest && !trip)
            Positioned(bottom: 20, left: 16, right: 16, child: Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('طلب جديد', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              const _LocationRow(icon: Icons.my_location, text: 'موقع الراكب', color: Colors.green),
              const _LocationRow(icon: Icons.location_on, text: 'الوجهة المحددة', color: Colors.red),
              const Divider(),
              const Text('الطلب جاي مباشرة من Firebase ويمكن قبوله من جهاز السائق.'),
              const SizedBox(height: 14),
              Row(children: [Expanded(child: OutlinedButton(onPressed: () { final id = _activeFirebaseRideId; if (id != null) _ignoredRideIds.add(id); _activeFirebaseRideId = null; RideHub.instance.clear(); }, child: const Text('رفض'))), const SizedBox(width: 10), Expanded(child: FilledButton(onPressed: () async {
                final rideId = _activeFirebaseRideId ?? RideHub.instance.activeRide.value?.id;
                if (rideId == null) return;
                try {
                  await _firebase.acceptRide(rideId, _driverId);
                  _driverRideSub?.cancel();
                  _driverRideSub = _firebase.rideStream(rideId).listen((event) {
                    final data = event.snapshot.value;
                    if (data is Map) {
                      final status = (data['status'] ?? 'accepted').toString();
                      final ride = RideHub.instance.activeRide.value;
                      if (ride != null) { ride.status = status == 'in_progress' ? 'started' : status; RideHub.instance.createRide(ride); }
                    }
                  });
                  RideHub.instance.acceptRide(_myLocation ?? _center);
                  await _startLiveLocation();
                } catch (_) {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر قبول الرحلة من Firebase.')));
                }
              }, style: FilledButton.styleFrom(backgroundColor: Colors.green), child: const Text('قبول')))]),
            ]))))
          else if (trip)
            Positioned(bottom: 20, left: 16, right: 16, child: Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
              const Text('طلب مقبول', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('الراكب: متصل الآن • موقعه ظاهر على الخريطة'),
              const SizedBox(height: 14),
              Row(children: [Expanded(child: FilledButton(onPressed: () async { final id = _activeFirebaseRideId; if (id != null) { try { await _firebase.updateRideStatus(id, 'in_progress'); } catch (_) {} } RideHub.instance.startRide(); }, style: FilledButton.styleFrom(backgroundColor: _yellow, foregroundColor: Colors.black), child: const Text('بدء الرحلة'))), const SizedBox(width: 10), Expanded(child: FilledButton(onPressed: () async { final id = _activeFirebaseRideId; if (id != null) { try { await _firebase.updateRideStatus(id, 'completed'); } catch (_) {} } RideHub.instance.finishRide(); if (mounted && id != null) await _showDriverRatingDialog(id); }, style: FilledButton.styleFrom(backgroundColor: Colors.red), child: const Text('إنهاء الرحلة')))]),
            ]))))
          else
            Positioned(bottom: 20, left: 16, right: 16, child: Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: const [Icon(Icons.check_circle_outline, size: 48, color: Colors.green), SizedBox(height: 8), Text('أنت متاح', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text('بانتظار طلبات جديدة...')])))),
        ]),
      ),
    );
  }
}

class _MapPoint { final LatLng point; final IconData icon; final Color color; const _MapPoint(this.point, this.icon, this.color); }

class _RealMap extends StatelessWidget {
  final MapController mapController;
  final LatLng center;
  final LatLng? userLocation;
  final LatLng? destination;
  final RouteResult? route;
  final void Function(TapPosition, LatLng)? onTap;
  final bool selectingDestination;
  final List<_MapPoint> extraMarkers;

  const _RealMap({required this.mapController, required this.center, this.userLocation, this.destination, this.route, this.onTap, this.selectingDestination = false, this.extraMarkers = const []});

  @override
  Widget build(BuildContext context) {
    final markers = <Marker>[];
    if (userLocation != null) markers.add(Marker(point: userLocation!, width: 50, height: 50, child: Container(decoration: BoxDecoration(color: Colors.blue.withOpacity(.16), shape: BoxShape.circle), child: const Icon(Icons.my_location, color: Colors.blue, size: 30))));
    if (destination != null) markers.add(Marker(point: destination!, width: 52, height: 52, child: const Icon(Icons.location_pin, color: Colors.red, size: 48)));
    for (final m in extraMarkers) { markers.add(Marker(point: m.point, width: 52, height: 52, child: Icon(m.icon, color: m.color, size: 42))); }

    return FlutterMap(
      mapController: mapController,
      options: MapOptions(initialCenter: center, initialZoom: 13.5, minZoom: 10, maxZoom: 19, onTap: onTap),
      children: [
        TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.moto.ride'),
        if (route != null && route!.points.length > 1) PolylineLayer(polylines: [Polyline(points: route!.points, strokeWidth: 5, color: Colors.black87)]),
        if (markers.isNotEmpty) MarkerLayer(markers: markers),
        const RichAttributionWidget(attributions: [TextSourceAttribution('© OpenStreetMap contributors')]),
        if (selectingDestination) const Align(alignment: Alignment.topCenter, child: Padding(padding: EdgeInsets.only(top: 112), child: IgnorePointer(child: Card(child: Padding(padding: EdgeInsets.symmetric(horizontal: 14, vertical: 8), child: Text('اضغط على أي مكان بالخريطة', style: TextStyle(fontWeight: FontWeight.bold))))))),
      ],
    );
  }
}

class _NewRideCard extends StatelessWidget {
  final bool selecting;
  final bool searching;
  final bool routingLoading;
  final LatLng? destination;
  final double distanceKm;
  final int fareIqd;
  final int etaMinutes;
  final VoidCallback onSelectDestination;
  final VoidCallback onRequest;

  const _NewRideCard({required this.selecting, required this.searching, required this.routingLoading, required this.destination, required this.distanceKm, required this.fareIqd, required this.etaMinutes, required this.onSelectDestination, required this.onRequest});

  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('رحلة جديدة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const _LocationRow(icon: Icons.my_location, text: 'موقعي الحالي', color: Colors.green),
        _LocationRow(icon: Icons.location_on, text: destination == null ? 'لم تُحدد الوجهة بعد' : 'الوجهة المحددة على الخريطة', color: Colors.red),
        const Divider(height: 24),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('المسافة'), Text(destination == null || routingLoading ? '—' : '${distanceKm.toStringAsFixed(1)} كم', style: const TextStyle(fontWeight: FontWeight.bold)), const Text('ETA'), Text(destination == null || routingLoading ? '—' : '$etaMinutes د', style: const TextStyle(fontWeight: FontWeight.bold))]),
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('الأجرة التقديرية'), Text(destination == null || routingLoading ? '—' : '${_formatIqd(fareIqd)} د.ع', style: const TextStyle(fontWeight: FontWeight.bold))]),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: selecting ? null : onSelectDestination, icon: const Icon(Icons.pin_drop), label: Text(selecting ? 'اختار نقطة من الخريطة...' : 'اختيار الوجهة على الخريطة'))),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: searching || routingLoading || destination == null ? null : onRequest, icon: const Icon(Icons.two_wheeler), label: Text(searching ? 'جاري البحث عن سائق...' : 'اطلب ماطور'), style: FilledButton.styleFrom(backgroundColor: _yellow, foregroundColor: Colors.black, minimumSize: const Size.fromHeight(52)))),
        const SizedBox(height: 6),
        const Text('المسافة والوقت من شبكة الطرق. الأجرة الحالية تجريبية وليست سعراً نهائياً.', style: TextStyle(fontSize: 12, color: Colors.black45)),
      ])));
}

class _TripCard extends StatelessWidget {
  final VoidCallback onFinish;
  final int fare;
  final int etaMinutes;
  const _TripCard({required this.onFinish, required this.fare, required this.etaMinutes});

  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        ListTile(contentPadding: EdgeInsets.zero, leading: const CircleAvatar(backgroundColor: _yellow, child: Icon(Icons.person, color: Colors.black)), title: const Text('علي محمد', style: TextStyle(fontWeight: FontWeight.bold)), subtitle: const Text('Honda 150 • 22-2567'), trailing: Text('$etaMinutes د', style: const TextStyle(fontWeight: FontWeight.bold))),
        const Divider(), const Text('الرحلة جارية', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text('الأجرة: ${_formatIqd(fare)} د.ع'), const SizedBox(height: 10),
        FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red, minimumSize: const Size.fromHeight(48)), onPressed: onFinish, child: const Text('إنهاء الرحلة')),
      ])));
}

class _DriverFoundSheet extends StatelessWidget {
  final VoidCallback onStart;
  final int fare;
  final double distanceKm;
  final int etaMinutes;
  const _DriverFoundSheet({required this.onStart, required this.fare, required this.distanceKm, required this.etaMinutes});

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Padding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 30), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const ListTile(leading: CircleAvatar(radius: 28, backgroundColor: _yellow, child: Icon(Icons.person, color: Colors.black)), title: Text('علي محمد', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), subtitle: Text('Honda 150 • 22-2567'), trailing: Text('4.8 ★')),
        const Divider(), Text('المسافة: ${distanceKm.toStringAsFixed(1)} كم • الوصول المتوقع: $etaMinutes د'), Text('الأجرة التقديرية: ${_formatIqd(fare)} د.ع'),
        const SizedBox(height: 6), const Text('هذا سائق تجريبي. الربط الحقيقي بين الراكب والسائق يأتي مع الخادم.'), const SizedBox(height: 14),
        Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.call), label: const Text('اتصال'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.message), label: const Text('رسالة')))]),
        const SizedBox(height: 10), SizedBox(width: double.infinity, child: FilledButton(onPressed: onStart, style: FilledButton.styleFrom(backgroundColor: _yellow, foregroundColor: Colors.black), child: const Text('بدء الرحلة'))),
      ])));
}

class _LocationRow extends StatelessWidget {
  final IconData icon; final String text; final Color color;
  const _LocationRow({required this.icon, required this.text, required this.color});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [Icon(icon, color: color, size: 22), const SizedBox(width: 10), Expanded(child: Text(text, style: const TextStyle(fontSize: 15)))]));
}

String _formatIqd(int value) {
  final text = value.toString(); final buffer = StringBuffer();
  for (var i = 0; i < text.length; i++) { if (i > 0 && (text.length - i) % 3 == 0) buffer.write(','); buffer.write(text[i]); }
  return buffer.toString();
}
