# Moto V16 — Notifications, Final Fare & Rating

Next product stage:
- Ride status changes are prepared for notification events.
- Final fare is calculated from the trip distance using the configured fare formula.
- Passenger can submit a 1–5 star rating after completion.
- Driver and passenger ride history can be shown from completed rides.
- Cancellation remains separate from completed trips.

Important:
- Push notifications require Firebase Cloud Messaging setup and device permissions.
- Production fare values must be confirmed before launch.
- Authentication and secure Firebase Realtime Database rules are still required for production.
