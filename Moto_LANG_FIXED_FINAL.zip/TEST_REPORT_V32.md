# Moto V32 — تقرير الحالة

- تم اكتشاف أن نسخة V31 لا تحتوي scaffold كامل لمنصة Android؛ كان موجوداً ملف `google-services.json` فقط داخل `android/app/`.
- تم تعديل GitHub Actions ليشغّل `flutter create --platforms=android` داخل بيئة البناء، ثم يضبط package ID إلى `com.moto.sulaymaniyah`.
- تمت إضافة Google Services plugin إلى إعدادات Android لاستخدام `android/app/google-services.json`.
- بعدها يتم تشغيل `flutter pub get` ثم `flutter analyze` ثم `flutter build apk --debug` ورفع APK كـ artifact باسم `moto-debug-apk`.
- لم يتم تنفيذ Flutter build داخل هذه البيئة لأن Flutter SDK غير مثبت هنا، لذلك لا يوجد ادعاء بأن APK تم اختباره فعلياً بعد.
- iOS ما زال يحتاج إعداد منصة iOS وملف Firebase الخاص بالآيفون قبل اعتباره جاهزاً.
