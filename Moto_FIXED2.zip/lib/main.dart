import 'dart:async';
import 'dart:math' as math;

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import 'routing_service.dart';
import 'firebase_service.dart';
import 'auth_service.dart';
import 'admin_dashboard.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MotoApp());
}

const _yellow = Color(0xFFFFC400);
const _sulaymaniyah = LatLng(35.5613, 45.4376);

class MotoApp extends StatelessWidget {
  const MotoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'موتو',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        colorScheme: ColorScheme.fromSeed(seedColor: _yellow),
        scaffoldBackgroundColor: const Color(0xFFF7F8FA),
      ),
      // لا نستدعي FirebaseAuth عند فتح التطبيق.
      // تهيئة Firebase وتسجيل الدخول تتم فقط بعد ضغط المستخدم على دخول/إنشاء حساب.
      home: const LoginScreen(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phone = TextEditingController();
  bool _loading = false;
  String? _verificationId;
  int? _resendToken;

  String _normalizeIraqPhone(String raw) {
    var value = raw.trim().replaceAll(RegExp(r'[^0-9+]'), '');
    if (value.startsWith('+964')) return value;
    if (value.startsWith('00964')) return '+${value.substring(2)}';
    if (value.startsWith('0')) return '+964${value.substring(1)}';
    if (value.startsWith('7')) return '+964$value';
    return value;
  }

  bool _isValidIraqPhone(String phone) => RegExp(r'^\+9647[0-9]{9}$').hasMatch(phone);

  Future<void> _sendCode() async {
    final phone = _normalizeIraqPhone(_phone.text);
    if (!_isValidIraqPhone(phone)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتب رقم عراقي صحيح، مثل 0750 123 4567')),
      );
      return;
    }

    setState(() => _loading = true);
    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp();
      }
      await MotoAuthService().verifyPhone(
        phoneNumber: phone,
        verificationCompleted: (credential) async {
          try {
            await FirebaseAuth.instance.signInWithCredential(credential);
            if (!mounted) return;
            _openRoleScreen();
          } catch (e) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('تعذر تأكيد الرقم: $e')),
              );
            }
          }
        },
        verificationFailed: (error) {
          if (!mounted) return;
          final message = switch (error.code) {
            'invalid-phone-number' => 'رقم الهاتف غير صحيح.',
            'too-many-requests' => 'محاولات كثيرة. حاول بعد قليل.',
            'operation-not-allowed' => 'تسجيل الهاتف غير مفعّل في إعدادات موتو بعد.',
            _ => 'تعذر إرسال رمز التحقق حالياً.',
          };
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
          setState(() => _loading = false);
        },
        codeSent: (verificationId, resendToken) {
          if (!mounted) return;
          setState(() {
            _verificationId = verificationId;
            _resendToken = resendToken;
            _loading = false;
          });
          _openOtpScreen(phone);
        },
        codeAutoRetrievalTimeout: (verificationId) {
          _verificationId = verificationId;
        },
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تشغيل التحقق: $e')),
      );
    }
  }

  void _openOtpScreen(String phone) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => OtpScreen(
          phone: phone,
          verificationId: _verificationId!,
          resendToken: _resendToken,
        ),
      ),
    );
  }

  void _openRoleScreen() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const RoleScreen()),
    );
  }

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      backgroundColor: const Color(0xFF111111),
      body: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFF111111),
                    const Color(0xFF1B1B1B),
                    const Color(0xFF080808),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 28, 24, 30),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const SizedBox(width: 44),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          border: Border.all(color: _yellow.withOpacity(.7)),
                          borderRadius: BorderRadius.circular(22),
                        ),
                        child: const Text('العربية ⌄', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 34),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.two_wheeler, color: _yellow, size: 42),
                      SizedBox(width: 8),
                      Text('MOTO', style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.w900, letterSpacing: 2)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text('كل ما تحتاجه ... يوصلك لك', style: TextStyle(color: Colors.white70, fontSize: 18)),
                  const SizedBox(height: 8),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: const [Icon(Icons.location_on, color: _yellow, size: 20), SizedBox(width: 4), Text('السليمانية', style: TextStyle(color: _yellow, fontSize: 17, fontWeight: FontWeight.bold))]),
                  const SizedBox(height: 28),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: const [
                      _ServiceTile(icon: Icons.person, label: 'نقل أشخاص'),
                      _ServiceTile(icon: Icons.shopping_cart_outlined, label: 'تسوق'),
                      _ServiceTile(icon: Icons.restaurant_outlined, label: 'مطاعم'),
                      _ServiceTile(icon: Icons.inventory_2_outlined, label: 'طلبات'),
                    ],
                  ),
                  const SizedBox(height: 30),
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      color: const Color(0xFF181818),
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: Colors.white12),
                      boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 24, offset: Offset(0, 10))],
                    ),
                    child: Column(
                      children: [
                        const Text('تسجيل الدخول', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 4),
                        const Text('أهلاً بك في موتو', style: TextStyle(color: Colors.white54, fontSize: 16)),
                        const SizedBox(height: 22),
                        TextField(
                          controller: _phone,
                          keyboardType: TextInputType.phone,
                          textDirection: TextDirection.ltr,
                          style: const TextStyle(color: Colors.white, fontSize: 18),
                          decoration: InputDecoration(
                            hintText: '0750 123 4567',
                            hintStyle: const TextStyle(color: Colors.white38),
                            labelText: 'رقم الهاتف',
                            labelStyle: const TextStyle(color: Colors.white60),
                            prefixIcon: const Icon(Icons.phone_outlined, color: _yellow),
                            filled: true,
                            fillColor: Colors.white.withOpacity(.04),
                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Colors.white24)),
                            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: _yellow, width: 1.5)),
                          ),
                        ),
                        const SizedBox(height: 18),
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: FilledButton(
                            onPressed: _loading ? null : _sendCode,
                            style: FilledButton.styleFrom(backgroundColor: _yellow, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                            child: Text(_loading ? 'جاري إرسال الرمز...' : 'إرسال رمز التحقق', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                          ),
                        ),
                        const SizedBox(height: 14),
                        const Text('سنرسل لك رمز تحقق SMS على رقمك', style: TextStyle(color: Colors.white38, fontSize: 13)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

class _ServiceTile extends StatelessWidget {
  final IconData icon;
  final String label;
  const _ServiceTile({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: 70,
    child: Column(children: [
      Container(width: 50, height: 50, decoration: BoxDecoration(color: const Color(0xFF202020), borderRadius: BorderRadius.circular(16), border: Border.all(color: _yellow.withOpacity(.5))), child: Icon(icon, color: _yellow)),
      const SizedBox(height: 6),
      Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 11)),
    ]),
  );
}

class OtpScreen extends StatefulWidget {
  final String phone;
  final String verificationId;
  final int? resendToken;
  const OtpScreen({super.key, required this.phone, required this.verificationId, this.resendToken});
  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final _code = TextEditingController();
  bool _loading = false;
  String _verificationId = '';

  @override
  void initState() {
    super.initState();
    _verificationId = widget.verificationId;
  }

  Future<void> _confirm() async {
    final code = _code.text.trim();
    if (code.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب رمز التحقق المكوّن من 6 أرقام.')));
      return;
    }
    setState(() => _loading = true);
    try {
      await MotoAuthService().confirmCode(verificationId: _verificationId, smsCode: code);
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const RoleScreen()), (_) => false);
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      final message = e.code == 'invalid-verification-code' ? 'رمز التحقق غير صحيح.' : 'تعذر تأكيد الرقم حالياً.';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      setState(() => _loading = false);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تأكيد الرقم: $e')));
      setState(() => _loading = false);
    }
  }

  @override
  void dispose() { _code.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      backgroundColor: const Color(0xFF111111),
      appBar: AppBar(backgroundColor: Colors.transparent, foregroundColor: Colors.white, title: const Text('تأكيد رقم الهاتف')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 40),
            const Icon(Icons.sms_outlined, color: _yellow, size: 64),
            const SizedBox(height: 20),
            const Text('أدخل رمز التحقق', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('أرسلنا رمزاً إلى ${widget.phone}', textDirection: TextDirection.ltr, style: const TextStyle(color: Colors.white60, fontSize: 15)),
            const SizedBox(height: 28),
            TextField(controller: _code, keyboardType: TextInputType.number, textAlign: TextAlign.center, maxLength: 6, style: const TextStyle(color: Colors.white, fontSize: 28, letterSpacing: 8), decoration: InputDecoration(counterText: '', hintText: '••••••', hintStyle: const TextStyle(color: Colors.white24), filled: true, fillColor: Colors.white10, enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Colors.white24)), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: _yellow)))),
            const SizedBox(height: 20),
            SizedBox(width: double.infinity, height: 56, child: FilledButton(onPressed: _loading ? null : _confirm, style: FilledButton.styleFrom(backgroundColor: _yellow, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))), child: Text(_loading ? 'جاري التأكيد...' : 'تأكيد الرقم', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)))),
          ],
        ),
      ),
    ),
  );
}

class RoleScreen extends StatelessWidget {
  const RoleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Spacer(),
                Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(color: _yellow, borderRadius: BorderRadius.circular(30)),
                  child: const Center(child: Icon(Icons.two_wheeler, size: 64, color: Colors.black)),
                ),
                const SizedBox(height: 18),
                const Text('موتو', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                const Text('نقل بالماطور — أسرع وأوفر', style: TextStyle(fontSize: 17, color: Colors.black54)),
                const Spacer(),
                _RoleButton(icon: Icons.person, title: 'أنا راكب', subtitle: 'أريد طلب رحلة', onTap: () async { final u = FirebaseAuth.instance.currentUser; if (u != null) { try { await MotoFirebaseService().saveUserProfile(uid: u.uid, email: u.email ?? '', role: 'passenger'); } catch (_) {} } if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const PassengerHome())); }),
                const SizedBox(height: 12),
                _RoleButton(icon: Icons.two_wheeler, title: 'أنا سائق', subtitle: 'أريد استقبال الرحلات', onTap: () { if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const DriverRegistrationScreen())); }),
                const SizedBox(height: 20),
                OutlinedButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminLoginScreen())),
                  icon: const Icon(Icons.admin_panel_settings),
                  label: const Text('دخول الإدارة'),
                ),
                const SizedBox(height: 12),
                const Text('نسخة تجريبية — خريطة + GPS + مسار حقيقي + ETA', style: TextStyle(color: Colors.black45)),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RoleButton extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _RoleButton({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        child: FilledButton(
          style: FilledButton.styleFrom(
            backgroundColor: Colors.white,
            foregroundColor: Colors.black,
            elevation: 1,
            padding: const EdgeInsets.all(18),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFE5E7EB))),
          ),
          onPressed: onTap,
          child: Row(
            children: [
              CircleAvatar(backgroundColor: _yellow, foregroundColor: Colors.black, child: Icon(icon)),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text(subtitle, style: const TextStyle(color: Colors.black54))])),
              const Icon(Icons.arrow_back_ios_new, size: 18),
            ],
          ),
        ),
      );
}


class RideRequest {
  RideRequest({required this.id, required this.origin, required this.destination, required this.fareIqd, required this.distanceKm, required this.etaMinutes});
  final String id;
  final LatLng origin;
  final LatLng destination;
  final int fareIqd;
  final double distanceKm;
  final int etaMinutes;
  String status = 'searching'; // searching, accepted, started, finished, cancelled
  LatLng? driverLocation;
  String driverName = 'علي محمد';
  String driverBike = 'Honda 150 • 22-2567';
}

class RideHub {
  RideHub._();
  static final RideHub instance = RideHub._();
  final ValueNotifier<RideRequest?> activeRide = ValueNotifier<RideRequest?>(null);

  void createRide(RideRequest ride) => activeRide.value = ride;
  void acceptRide(LatLng driverLocation) {
    final ride = activeRide.value;
    if (ride == null) return;
    ride.status = 'accepted';
    ride.driverLocation = driverLocation;
    activeRide.value = ride;
  }
  void updateDriverLocation(LatLng point) {
    final ride = activeRide.value;
    if (ride == null) return;
    ride.driverLocation = point;
    activeRide.value = ride;
  }
  void startRide() {
    final ride = activeRide.value;
    if (ride == null) return;
    ride.status = 'started';
    activeRide.value = ride;
  }
  void finishRide() {
    final ride = activeRide.value;
    if (ride == null) return;
    ride.status = 'finished';
    activeRide.value = ride;
  }
  void clear() => activeRide.value = null;
}

class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});
  @override
  State<PassengerHome> createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  final MapController _mapController = MapController();
  final RoutingService _routing = RoutingService();
  LatLng _center = _sulaymaniyah;
  LatLng? _myLocation;
  LatLng? _destination;
  RouteResult? _route;
  bool _locating = false;
  final MotoFirebaseService _firebase = MotoFirebaseService();
  StreamSubscription<DatabaseEvent>? _firebaseRideSub;
  StreamSubscription<DatabaseEvent>? _driverLocationSub;
  String? _firebaseRideId;
  String get _passengerId => FirebaseAuth.instance.currentUser?.uid ?? 'anonymous';
  bool _searching = false;
  bool _tripStarted = false;
  bool _tripFinished = false;
  bool _selectingDestination = false;
  bool _routingLoading = false;
  double _baseFare = 1000;
  double _perKm = 500;
  StreamSubscription<DatabaseEvent>? _pricingSub;

  @override
  void initState() { super.initState(); RideHub.instance.activeRide.addListener(_onRideChanged); _loadPricing(); _pricingSub = _firebase.pricingStream().listen((event) { final v = event.snapshot.value; if (v is Map) { final b = v['baseFare']; final k = v['perKm']; if (mounted) setState(() { if (b is num) _baseFare = b.toDouble(); if (k is num) _perKm = k.toDouble(); }); } }); }
  @override
  void dispose() { RideHub.instance.activeRide.removeListener(_onRideChanged); _firebaseRideSub?.cancel(); _driverLocationSub?.cancel(); _pricingSub?.cancel(); super.dispose(); }
  void _onRideChanged() { final ride = RideHub.instance.activeRide.value; if (!mounted || ride == null) return; setState(() { _tripStarted = ride.status == 'started'; _searching = ride.status == 'searching'; if (ride.status == 'finished') _tripFinished = true; }); }

  LatLng get _origin => _myLocation ?? _center;
  double get _distanceKm => _route?.distanceKm ?? 0;
  int get _fareIqd {
    if (_route == null) return 0;
    final raw = _baseFare + (_distanceKm * _perKm);
    final rounded = ((raw / 250).round() * 250).clamp(_baseFare, 100000);
    return rounded.round();
  }

  Future<void> _loadPricing() async {
    try {
      final snap = await _firebase.db.ref('settings/pricing').get();
      final v = snap.value;
      if (v is Map && mounted) {
        setState(() {
          if (v['baseFare'] is num) _baseFare = (v['baseFare'] as num).toDouble();
          if (v['perKm'] is num) _perKm = (v['perKm'] as num).toDouble();
        });
      }
    } catch (_) {}
  }

  Future<void> _locateMe() async {
    setState(() => _locating = true);
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showMessage('فعّل خدمة الموقع (GPS) من إعدادات الهاتف.');
        return;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        _showMessage('لازم تسمح للتطبيق باستخدام الموقع.');
        return;
      }
      final position = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      final point = LatLng(position.latitude, position.longitude);
      setState(() {
        _myLocation = point;
        _center = point;
      });
      _mapController.move(point, 15.5);
      final ride = RideHub.instance.activeRide.value;
      if (ride != null && (ride.status == 'accepted' || ride.status == 'started')) {
        RideHub.instance.updateDriverLocation(point);
        if (_firebaseRideId != null) { try { await _firebase.updateRideDriverLocation(_firebaseRideId!, point.latitude, point.longitude); } catch (_) {} }
      }
      if (_destination != null) await _loadRoute(point, _destination!);
    } catch (_) {
      _showMessage('تعذر تحديد موقعك حالياً.');
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _loadRoute(LatLng from, LatLng to) async {
    setState(() {
      _routingLoading = true;
      _route = null;
    });
    try {
      final result = await _routing.getRoute(from, to);
      if (!mounted) return;
      setState(() => _route = result);
      _fitRoute(result.points);
    } catch (_) {
      _showMessage('تعذر حساب المسار. تأكد من الإنترنت وحاول مرة ثانية.');
    } finally {
      if (mounted) setState(() => _routingLoading = false);
    }
  }

  void _fitRoute(List<LatLng> points) {
    if (points.length < 2) return;
    final lats = points.map((p) => p.latitude).toList();
    final lons = points.map((p) => p.longitude).toList();
    final bounds = LatLngBounds(LatLng(lats.reduce(math.min), lons.reduce(math.min)), LatLng(lats.reduce(math.max), lons.reduce(math.max)));
    _mapController.fitCamera(CameraFit.bounds(bounds: bounds, padding: const EdgeInsets.fromLTRB(70, 160, 70, 300)));
  }

  Future<void> _onMapTap(TapPosition _, LatLng point) async {
    if (!_selectingDestination) return;
    setState(() {
      _destination = point;
      _selectingDestination = false;
    });
    await _loadRoute(_origin, point);
    _showMessage('تم تحديد الوجهة وحساب المسار حسب الشوارع.');
  }

  void _showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _requestRide() async {
    if (_destination == null || _route == null) {
      _showMessage('حدد الوجهة وانتظر ظهور المسافة أولاً.');
      return;
    }
    setState(() => _searching = true);
    try {
      final rideId = await _firebase.createRide(
        passengerId: _passengerId,
        pickupLat: _origin.latitude,
        pickupLng: _origin.longitude,
        destinationLat: _destination!.latitude,
        destinationLng: _destination!.longitude,
        fare: _fareIqd.toDouble(),
        distanceKm: _distanceKm,
      );
      _firebaseRideId = rideId;
      await _firebaseRideSub?.cancel();
      _firebaseRideSub = _firebase.rideStream(rideId).listen((event) async {
        final data = event.snapshot.value;
        if (data is! Map) return;
        final status = (data['status'] ?? 'searching').toString();
        final ride = RideHub.instance.activeRide.value ?? RideRequest(
          id: rideId,
          origin: _origin,
          destination: _destination!,
          fareIqd: _fareIqd,
          distanceKm: _distanceKm,
          etaMinutes: _route?.etaMinutes ?? 0,
        );
        ride.status = status == 'in_progress' ? 'started' : (status == 'completed' ? 'finished' : status);
        final driverId = data['driverId']?.toString();
        if (driverId != null && driverId.isNotEmpty) {
          try {
            final ds = await _firebase.drivers.child(driverId).get();
            final dv = ds.value;
            if (dv is Map) {
              ride.driverName = (dv['name'] ?? dv['email'] ?? ride.driverName).toString();
              ride.driverBike = (dv['bike'] ?? ride.driverBike).toString();
            }
          } catch (_) {}
        }
        final loc = data['driverLocation'];
        if (loc is Map && loc['lat'] != null && loc['lng'] != null) {
          ride.driverLocation = LatLng((loc['lat'] as num).toDouble(), (loc['lng'] as num).toDouble());
          if (mounted && (status == 'accepted' || status == 'in_progress')) {
            _mapController.move(ride.driverLocation!, 15.5);
          }
        }
        RideHub.instance.createRide(ride);
        if (mounted && status == 'accepted') _showMessage('تم قبول الرحلة من السائق 🏍️');
      });
      final localRide = RideRequest(id: rideId, origin: _origin, destination: _destination!, fareIqd: _fareIqd, distanceKm: _distanceKm, etaMinutes: _route!.etaMinutes);
      RideHub.instance.createRide(localRide);
      _showMessage('تم إرسال الطلب إلى السائقين القريبين.');
    } catch (_) {
      _showMessage('تعذر إرسال الطلب إلى Firebase. تأكد من إعداد Firebase وقواعد قاعدة البيانات.');
      setState(() => _searching = false);
    }
  }

  Future<void> _resetRide() async {
    if (_firebaseRideId != null) {
      try { await _firebase.cancelRide(_firebaseRideId!); } catch (_) {}
    }
    await _firebaseRideSub?.cancel();
    _firebaseRideId = null;
    RideHub.instance.clear();
    setState(() {
      _destination = null;
      _route = null;
      _searching = false;
      _tripStarted = false;
      _tripFinished = false;
      _selectingDestination = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('موتو'), actions: [IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MarketplaceHome())), icon: const Icon(Icons.storefront_outlined), tooltip: 'سوق موتو'), IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PassengerAccountScreen())), icon: const Icon(Icons.person_outline)), IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PassengerHistoryScreen())), icon: const Icon(Icons.history)), IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)), IconButton(onPressed: () async { await MotoAuthService().signOut(); if (context.mounted) Navigator.popUntil(context, (r) => r.isFirst); }, icon: const Icon(Icons.logout))]),
        body: Stack(
          children: [
            _RealMap(
              mapController: _mapController,
              center: _center,
              userLocation: _myLocation,
              destination: _destination,
              route: _route,
              onTap: _onMapTap,
              selectingDestination: _selectingDestination,
              extraMarkers: RideHub.instance.activeRide.value?.driverLocation == null
                  ? const []
                  : [_MapPoint(RideHub.instance.activeRide.value!.driverLocation!, Icons.two_wheeler, Colors.black)],
            ),
            Positioned(
              top: 16,
              right: 16,
              left: 16,
              child: Card(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13), child: Row(children: [
                Icon(_selectingDestination ? Icons.touch_app : Icons.map, color: _selectingDestination ? Colors.green : Colors.black54),
                const SizedBox(width: 10),
                Expanded(child: Text(_selectingDestination ? 'اضغط على الخريطة لتحديد الوجهة' : (_destination == null ? 'حدد وجهتك من الخريطة' : (_routingLoading ? 'جاري حساب الطريق...' : 'تم حساب الطريق')) , style: const TextStyle(fontSize: 16, color: Colors.black54))),
              ]))),
            ),
            Positioned(top: 84, right: 16, child: FloatingActionButton.small(heroTag: 'gps-passenger', onPressed: _locating ? null : _locateMe, backgroundColor: Colors.white, foregroundColor: Colors.black, child: _locating ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.my_location))),
            if (_destination != null && !_tripStarted && !_tripFinished)
              Positioned(top: 84, left: 16, child: FloatingActionButton.small(heroTag: 'clear-destination', onPressed: () => setState(() { _destination = null; _route = null; }), backgroundColor: Colors.white, foregroundColor: Colors.red, child: const Icon(Icons.close))),
            if (_tripStarted && !_tripFinished)
              Positioned(left: 16, right: 16, bottom: 20, child: _TripCard(onFinish: () => setState(() => _tripFinished = true), fare: _fareIqd, etaMinutes: _route?.etaMinutes ?? 0))
            else if (!_tripFinished)
              Positioned(left: 16, right: 16, bottom: 20, child: _NewRideCard(selecting: _selectingDestination, searching: _searching, routingLoading: _routingLoading, destination: _destination, distanceKm: _distanceKm, fareIqd: _fareIqd, etaMinutes: _route?.etaMinutes ?? 0, onSelectDestination: () => setState(() => _selectingDestination = true), onRequest: _requestRide))
            else
              Positioned.fill(child: Center(child: Card(margin: const EdgeInsets.all(30), child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.check_circle, size: 70, color: Colors.green),
                const SizedBox(height: 12),
                const Text('وصلت بالسلامة!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('المبلغ النهائي: ${_formatIqd(_fareIqd)} د.ع'),
                const SizedBox(height: 18),
                Column(children: [
                  const Text('قيّم السائق'),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      5,
                      (i) => IconButton(
                        onPressed: () async {
                          if (_firebaseRideId != null) {
                            try {
                              await _firebase.rateRide(
                                rideId: _firebaseRideId!,
                                passengerId: _passengerId,
                                rating: i + 1,
                              );
                              _showMessage('تم حفظ تقييمك ⭐');
                            } catch (_) {}
                          }
                        },
                        icon: const Icon(Icons.star, color: _yellow, size: 32),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  FilledButton(onPressed: _resetRide, child: const Text('رحلة جديدة')),
                ]),
              ])))))
          ],
        ),
      ),
    );
  }
}


class ShopCategory {
  final String name;
  final IconData icon;
  const ShopCategory(this.name, this.icon);
}

class ShopProduct {
  final String name;
  final String shop;
  final String category;
  final int price;
  final IconData icon;
  const ShopProduct({required this.name, required this.shop, required this.category, required this.price, required this.icon});
}

const _marketCategories = <ShopCategory>[
  ShopCategory('مطاعم', Icons.restaurant),
  ShopCategory('بقالة', Icons.local_grocery_store),
  ShopCategory('خضار وفواكه', Icons.eco),
  ShopCategory('مخابز وحلويات', Icons.bakery_dining),
  ShopCategory('لحوم ودجاج', Icons.set_meal),
  ShopCategory('موبايلات وإلكترونيات', Icons.phone_android),
  ShopCategory('ملابس', Icons.checkroom),
  ShopCategory('أحذية وحقائب', Icons.shopping_bag),
  ShopCategory('تجميل وعناية', Icons.spa),
  ShopCategory('منزل وأثاث', Icons.chair),
  ShopCategory('أجهزة منزلية', Icons.kitchen),
  ShopCategory('مستلزمات أطفال', Icons.child_friendly),
  ShopCategory('قرطاسية وكتب', Icons.menu_book),
  ShopCategory('هدايا وورد', Icons.card_giftcard),
  ShopCategory('إكسسوارات ومجوهرات', Icons.watch),
  ShopCategory('رياضة', Icons.sports_soccer),
  ShopCategory('سيارات ودراجات', Icons.two_wheeler),
  ShopCategory('عدد وأدوات', Icons.build),
  ShopCategory('حيوانات أليفة', Icons.pets),
  ShopCategory('صيدليات وصحة', Icons.local_pharmacy),
];

const _marketProducts = <ShopProduct>[
  ShopProduct(name: 'وجبة دجاج مشوي', shop: 'مطعم موتو', category: 'مطاعم', price: 7000, icon: Icons.restaurant),
  ShopProduct(name: 'برغر لحم', shop: 'برغر السليمانية', category: 'مطاعم', price: 6500, icon: Icons.lunch_dining),
  ShopProduct(name: 'سلة مواد غذائية', shop: 'ماركت المدينة', category: 'بقالة', price: 25000, icon: Icons.local_grocery_store),
  ShopProduct(name: 'فواكه مشكلة', shop: 'سوق الخضار', category: 'خضار وفواكه', price: 10000, icon: Icons.eco),
  ShopProduct(name: 'كعكة شوكولاتة', shop: 'حلويات روز', category: 'مخابز وحلويات', price: 12000, icon: Icons.cake),
  ShopProduct(name: 'دجاج طازج', shop: 'ملحمة السليمانية', category: 'لحوم ودجاج', price: 14000, icon: Icons.set_meal),
  ShopProduct(name: 'سماعة لاسلكية', shop: 'موبايل ستور', category: 'موبايلات وإلكترونيات', price: 18000, icon: Icons.headphones),
  ShopProduct(name: 'تيشيرت رجالي', shop: 'ستايل مول', category: 'ملابس', price: 20000, icon: Icons.checkroom),
  ShopProduct(name: 'حقيبة نسائية', shop: 'فاشن ستور', category: 'أحذية وحقائب', price: 35000, icon: Icons.shopping_bag),
  ShopProduct(name: 'عطر فاخر', shop: 'عطور موتو', category: 'تجميل وعناية', price: 30000, icon: Icons.spa),
  ShopProduct(name: 'مصباح مكتب', shop: 'بيت وأثاث', category: 'منزل وأثاث', price: 22000, icon: Icons.lightbulb_outline),
  ShopProduct(name: 'خلاط كهربائي', shop: 'أجهزة البيت', category: 'أجهزة منزلية', price: 45000, icon: Icons.blender),
  ShopProduct(name: 'طقم أطفال', shop: 'عالم الطفل', category: 'مستلزمات أطفال', price: 28000, icon: Icons.child_friendly),
  ShopProduct(name: 'دفتر ملاحظات', shop: 'المكتبة الحديثة', category: 'قرطاسية وكتب', price: 5000, icon: Icons.menu_book),
  ShopProduct(name: 'باقة ورد', shop: 'ورد السليمانية', category: 'هدايا وورد', price: 20000, icon: Icons.local_florist),
  ShopProduct(name: 'ساعة يد', shop: 'إكسسوارات موتو', category: 'إكسسوارات ومجوهرات', price: 40000, icon: Icons.watch),
  ShopProduct(name: 'كرة قدم', shop: 'سبورت سنتر', category: 'رياضة', price: 18000, icon: Icons.sports_soccer),
  ShopProduct(name: 'خوذة دراجة', shop: 'موتو بايك', category: 'سيارات ودراجات', price: 50000, icon: Icons.sports_motorsports),
  ShopProduct(name: 'عدة مفكات', shop: 'الأدوات الحديثة', category: 'عدد وأدوات', price: 15000, icon: Icons.build),
  ShopProduct(name: 'طعام قطط', shop: 'عالم الحيوانات', category: 'حيوانات أليفة', price: 12000, icon: Icons.pets),
];

String _marketIqd(int value) => '${value.toString().replaceAllMapped(RegExp(r'(?=(\d{3})+(?!\d))'), (m) => ',')} د.ع';

class MarketplaceHome extends StatefulWidget {
  const MarketplaceHome({super.key});
  @override State<MarketplaceHome> createState() => _MarketplaceHomeState();
}

class _MarketplaceHomeState extends State<MarketplaceHome> {
  String _selectedCategory = 'الكل';
  final List<ShopProduct> _cart = [];
  final _search = TextEditingController();

  List<ShopProduct> get _visibleProducts {
    final q = _search.text.trim().toLowerCase();
    return _marketProducts.where((p) {
      final categoryOk = _selectedCategory == 'الكل' || p.category == _selectedCategory;
      final searchOk = q.isEmpty || p.name.toLowerCase().contains(q) || p.shop.toLowerCase().contains(q);
      return categoryOk && searchOk;
    }).toList();
  }

  int get _cartTotal => _cart.fold(0, (sum, p) => sum + p.price);

  @override
  void dispose() { _search.dispose(); super.dispose(); }

  void _addToCart(ShopProduct product) {
    setState(() => _cart.add(product));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تمت إضافة ${product.name} للسلة 🛒')));
  }

  Future<void> _openCart() async {
    if (_cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('السلة فارغة حالياً.')));
      return;
    }
    await Navigator.push(context, MaterialPageRoute(builder: (_) => CheckoutScreen(items: List.unmodifiable(_cart), total: _cartTotal)));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('سوق موتو'),
          actions: [
            Stack(children: [
              IconButton(onPressed: _openCart, icon: const Icon(Icons.shopping_cart_outlined)),
              if (_cart.isNotEmpty) Positioned(left: 6, top: 6, child: CircleAvatar(radius: 9, backgroundColor: _yellow, child: Text('${_cart.length}', style: const TextStyle(fontSize: 10, color: Colors.black, fontWeight: FontWeight.bold)))),
            ]),
          ],
        ),
        body: CustomScrollView(slivers: [
          SliverList(
            delegate: SliverChildListDelegate([
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
            Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: const Color(0xFF111111), borderRadius: BorderRadius.circular(24)), child: Row(children: [
              Container(width: 54, height: 54, decoration: BoxDecoration(color: _yellow, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.delivery_dining, color: Colors.black, size: 32)),
              const SizedBox(width: 14),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('كل احتياجاتك بمكان واحد', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)), SizedBox(height: 4), Text('تسوّق من المحلات وخلي موتو يوصّلها لبابك', style: TextStyle(color: Colors.white70, height: 1.3))])),
            ])),
            const SizedBox(height: 14),
            TextField(controller: _search, onChanged: (_) => setState(() {}), decoration: InputDecoration(hintText: 'ابحث عن مطعم، محل، منتج...', prefixIcon: const Icon(Icons.search), suffixIcon: _search.text.isEmpty ? null : IconButton(onPressed: () { _search.clear(); setState(() {}); }, icon: const Icon(Icons.clear)), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none))),
            const SizedBox(height: 16),
            const Text('تسوّق حسب القسم', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            SizedBox(height: 106, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: _marketCategories.length + 1, separatorBuilder: (_, __) => const SizedBox(width: 10), itemBuilder: (_, i) {
              final isAll = i == 0;
              final c = isAll ? const ShopCategory('الكل', Icons.apps) : _marketCategories[i - 1];
              final selected = _selectedCategory == c.name;
              return InkWell(onTap: () => setState(() => _selectedCategory = c.name), borderRadius: BorderRadius.circular(18), child: Container(width: 88, padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10), decoration: BoxDecoration(color: selected ? _yellow : Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: selected ? _yellow : const Color(0xFFE5E7EB))), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(c.icon, color: Colors.black, size: 30), const SizedBox(height: 6), Text(c.name, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))])));
            })),
            const SizedBox(height: 16),
            Row(children: [const Expanded(child: Text('محلات ومنتجات قريبة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))), Text('${_visibleProducts.length} منتج', style: const TextStyle(color: Colors.black54))]),
                  ],
                ),
              ),
            ]),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            sliver: _visibleProducts.isEmpty
                ? SliverList(
                    delegate: SliverChildListDelegate([
                      const Padding(
                        padding: EdgeInsets.all(30),
                        child: Center(child: Text('ما لقينا نتائج بهالقسم حالياً.')),
                      ),
                    ]),
                  )
                : SliverGrid(delegate: SliverChildBuilderDelegate((context, i) {
            final p = _visibleProducts[i];
            return Card(clipBehavior: Clip.antiAlias, elevation: 1, child: InkWell(onTap: () => _addToCart(p), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: Container(width: double.infinity, decoration: BoxDecoration(color: const Color(0xFFFFF4CC), borderRadius: BorderRadius.circular(16)), child: Icon(p.icon, size: 48, color: Colors.black87))),
              const SizedBox(height: 9),
              Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 3),
              Text(p.shop, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.black54)),
              const SizedBox(height: 7),
              Row(children: [Expanded(child: Text(_marketIqd(p.price), style: const TextStyle(fontWeight: FontWeight.w900))), Container(width: 34, height: 34, decoration: BoxDecoration(color: _yellow, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.add, color: Colors.black))]),
            ]))));
          }, childCount: _visibleProducts.length), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .72)),
          ),
        ]),
      ),
    );
  }
}

class CheckoutScreen extends StatefulWidget {
  final List<ShopProduct> items;
  final int total;
  const CheckoutScreen({super.key, required this.items, required this.total});
  @override State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _address = TextEditingController();
  bool _placing = false;

  int get _deliveryFee => 2000;
  int get _grandTotal => widget.total + _deliveryFee;

  @override
  void dispose() { _address.dispose(); super.dispose(); }

  Future<void> _placeOrder() async {
    if (_address.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب عنوان التوصيل أولاً.')));
      return;
    }
    setState(() => _placing = true);
    try {
      if (Firebase.apps.isEmpty) await Firebase.initializeApp();
      final uid = FirebaseAuth.instance.currentUser?.uid ?? 'guest';
      final ref = FirebaseDatabase.instance.ref('users').child(uid).child('orders').push();
      await ref.set({
        'customerId': uid,
        'type': 'shopping',
        'status': 'pending',
        'address': _address.text.trim(),
        'subtotal': widget.total,
        'deliveryFee': _deliveryFee,
        'total': _grandTotal,
        'paymentMethod': 'cash_on_delivery',
        'createdAt': ServerValue.timestamp,
        'items': widget.items.map((p) => {'name': p.name, 'shop': p.shop, 'category': p.category, 'price': p.price}).toList(),
      });
      if (!mounted) return;
      await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('تم إرسال طلبك 🎉'), content: Text('رقم الطلب: ${ref.key}\nموتو راح يتابع تجهيز الطلب وتوصيله إلى العنوان.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('تمام'))]));
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إرسال الطلب حالياً: $e')));
    } finally {
      if (mounted) setState(() => _placing = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(appBar: AppBar(title: const Text('تأكيد الطلب')), body: ListView(padding: const EdgeInsets.all(16), children: [
    const Text('محتويات السلة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    ...widget.items.map<Widget>((p) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: _yellow, child: Icon(p.icon, color: Colors.black)), title: Text(p.name), subtitle: Text(p.shop), trailing: Text(_marketIqd(p.price))))).toList(growable: false),
    const SizedBox(height: 14),
    TextField(controller: _address, maxLines: 2, decoration: const InputDecoration(labelText: 'عنوان التوصيل', hintText: 'الحي، الشارع، أقرب نقطة دالة', prefixIcon: Icon(Icons.location_on_outlined), border: OutlineInputBorder())),
    const SizedBox(height: 14),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      _totalRow('قيمة المنتجات', widget.total),
      _totalRow('أجرة التوصيل', _deliveryFee),
      const Divider(),
      _totalRow('الإجمالي', _grandTotal, bold: true),
      const SizedBox(height: 8),
      const Row(children: [Icon(Icons.payments_outlined), SizedBox(width: 8), Text('الدفع عند الاستلام')]),
    ]))),
    const SizedBox(height: 16),
    SizedBox(height: 54, child: FilledButton(onPressed: _placing ? null : _placeOrder, style: FilledButton.styleFrom(backgroundColor: _yellow, foregroundColor: Colors.black), child: Text(_placing ? 'جاري إرسال الطلب...' : 'اطلب الآن'))),
  ])));
}

Widget _totalRow(String label, int value, {bool bold = false}) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [Expanded(child: Text(label, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.normal))), Text(_marketIqd(value), style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.normal))]));


class PassengerAccountScreen extends StatefulWidget {
  const PassengerAccountScreen({super.key});
  @override State<PassengerAccountScreen> createState() => _PassengerAccountScreenState();
}

class _PassengerAccountScreenState extends State<PassengerAccountScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _firebase = MotoFirebaseService();
  bool _loading = true;
  String _email = '';
  String get _uid => FirebaseAuth.instance.currentUser?.uid ?? '';

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    if (_uid.isEmpty) return;
    try {
      final snap = await _firebase.users.child(_uid).get();
      final v = snap.value;
      if (v is Map) { _name.text = (v['name'] ?? '').toString(); _phone.text = (v['phone'] ?? '').toString(); _email = (v['email'] ?? FirebaseAuth.instance.currentUser?.email ?? '').toString(); }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }
  Future<void> _save() async {
    if (_uid.isEmpty || _phone.text.trim().isEmpty) return;
    try { await _firebase.savePassengerProfile(uid: _uid, email: _email, name: _name.text.trim(), phone: _phone.text.trim()); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ بياناتك ✅'))); } catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر الحفظ. تأكد من Firebase.'))); }
  }
  @override Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(appBar: AppBar(title: const Text('حسابي')), body: _loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(20), children: [
    const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 44)), const SizedBox(height: 20),
    TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم الكامل', prefixIcon: Icon(Icons.person), border: OutlineInputBorder())), const SizedBox(height: 14),
    TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف', prefixIcon: Icon(Icons.phone), border: OutlineInputBorder())), const SizedBox(height: 14),
    Text('البريد: $_email', style: const TextStyle(color: Colors.black54)), const SizedBox(height: 20),
    FilledButton(onPressed: _save, child: const Text('حفظ البيانات')),
  ])));
}

class PassengerHistoryScreen extends StatelessWidget {
  const PassengerHistoryScreen({super.key});
  @override Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
    final firebase = MotoFirebaseService();
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(appBar: AppBar(title: const Text('سجل الرحلات')), body: StreamBuilder<DatabaseEvent>(stream: firebase.passengerRidesStream(uid), builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      final raw = snap.data?.snapshot.value;
      if (raw is! Map || raw.isEmpty) return const Center(child: Text('ما عندك رحلات سابقة بعد.'));
      final rows = <Map<String, dynamic>>[];
      raw.forEach((key, value) { if (value is Map) { rows.add({'id': key.toString(), ...Map<String, dynamic>.from(value)}); } });
      rows.sort((a,b) => ((b['createdAt'] ?? 0) as num).compareTo((a['createdAt'] ?? 0) as num));
      return ListView.separated(padding: const EdgeInsets.all(12), itemCount: rows.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) {
        final r = rows[i]; final status = (r['status'] ?? '—').toString(); final fare = ((r['fare'] ?? 0) as num).round(); final rating = r['passengerRating'] ?? r['rating'];
        return Card(child: ListTile(leading: CircleAvatar(child: Icon(status == 'completed' ? Icons.check : Icons.two_wheeler)), title: Text('${_formatIqd(fare)} د.ع'), subtitle: Text('الحالة: $status • المسافة: ${((r['distanceKm'] ?? 0) as num).toStringAsFixed(1)} كم${rating == null ? '' : ' • التقييم: $rating/5'}'), trailing: const Icon(Icons.chevron_left)));
      });
    })));
  }
}


class DriverRegistrationScreen extends StatefulWidget {
  const DriverRegistrationScreen({super.key});
  @override State<DriverRegistrationScreen> createState() => _DriverRegistrationScreenState();
}

class _DriverRegistrationScreenState extends State<DriverRegistrationScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _bike = TextEditingController();
  final _plate = TextEditingController();
  final _firebase = MotoFirebaseService();
  bool _loading = true;
  bool _saving = false;
  bool _approved = false;
  bool _blocked = false;
  String _status = 'pending';

  String get _uid => FirebaseAuth.instance.currentUser?.uid ?? '';
  String get _email => FirebaseAuth.instance.currentUser?.email ?? '';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      if (_uid.isEmpty) return;
      final snap = await _firebase.drivers.child(_uid).get();
      final v = snap.value;
      if (v is Map) {
        final d = Map<String, dynamic>.from(v);
        _name.text = (d['name'] ?? '').toString();
        _phone.text = (d['phone'] ?? '').toString();
        _bike.text = (d['bike'] ?? '').toString();
        _plate.text = (d['plate'] ?? '').toString();
        _approved = d['approved'] == true;
        _blocked = d['blocked'] == true;
        _status = (d['applicationStatus'] ?? (_approved ? 'approved' : 'pending')).toString();
      }
    } finally { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _submit() async {
    if (_name.text.trim().isEmpty || _phone.text.trim().isEmpty || _bike.text.trim().isEmpty || _plate.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('كمل الاسم ورقم الهاتف ونوع الماطور ورقم اللوحة.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await _firebase.submitDriverApplication(uid: _uid, email: _email, name: _name.text.trim(), phone: _phone.text.trim(), bike: _bike.text.trim(), plate: _plate.text.trim());
      if (mounted) setState(() { _status = 'pending'; _approved = false; _blocked = false; });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرسال بياناتك للإدارة للموافقة.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر حفظ البيانات. تأكد من اتصال Firebase.')));
    } finally { if (mounted) setState(() => _saving = false); }
  }

  @override void dispose() { _name.dispose(); _phone.dispose(); _bike.dispose(); _plate.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(title: const Text('تسجيل بيانات السائق')),
    body: _loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(20), children: [
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        const Icon(Icons.two_wheeler, size: 54), const SizedBox(height: 8),
        const Text('بيانات السائق', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6), const Text('بعد الإرسال، الإدارة تراجع البيانات قبل تفعيل استقبال الرحلات.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
      ]))),
      const SizedBox(height: 14),
      if (_blocked) Card(color: Colors.red.shade50, child: const ListTile(leading: Icon(Icons.block, color: Colors.red), title: Text('الحساب محظور'), subtitle: Text('راجع الإدارة قبل محاولة التفعيل.')))
      else if (_approved) Card(color: Colors.green.shade50, child: ListTile(leading: const Icon(Icons.verified, color: Colors.green), title: const Text('تمت الموافقة على حسابك'), subtitle: const Text('تقدر تدخل وتستقبل الرحلات.'), trailing: FilledButton(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const DriverHome())), child: const Text('دخول'))))
      else Card(color: Colors.orange.shade50, child: ListTile(leading: const Icon(Icons.hourglass_top), title: const Text('بانتظار موافقة الإدارة'), subtitle: Text(_status == 'pending' ? 'بياناتك قيد المراجعة.' : 'أرسل بياناتك حتى تبدأ المراجعة.'))),
      const SizedBox(height: 14),
      TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم الكامل', border: OutlineInputBorder(), prefixIcon: Icon(Icons.person))),
      const SizedBox(height: 12), TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف', border: OutlineInputBorder(), prefixIcon: Icon(Icons.phone))),
      const SizedBox(height: 12), TextField(controller: _bike, decoration: const InputDecoration(labelText: 'نوع الماطور (مثلاً Honda 150)', border: OutlineInputBorder(), prefixIcon: Icon(Icons.two_wheeler))),
      const SizedBox(height: 12), TextField(controller: _plate, decoration: const InputDecoration(labelText: 'رقم اللوحة', border: OutlineInputBorder(), prefixIcon: Icon(Icons.confirmation_number))),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: _saving ? null : _submit, icon: const Icon(Icons.send), label: Text(_saving ? 'جاري الحفظ...' : 'إرسال للموافقة')),
      const SizedBox(height: 10),
      if (_approved) OutlinedButton.icon(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const DriverHome())), icon: const Icon(Icons.login), label: const Text('الدخول للسائق')),
    ]),
  ));
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final MapController _mapController = MapController();
  LatLng _center = _sulaymaniyah;
  LatLng? _myLocation;
  bool online = false;
  bool hasRequest = false;
  bool trip = false;
  LatLng? _passengerLocation;
  LatLng? _destination;
  bool _locating = false;
  final MotoFirebaseService _firebase = MotoFirebaseService();
  StreamSubscription<DatabaseEvent>? _requestsSub;
  StreamSubscription<DatabaseEvent>? _driverRideSub;
  StreamSubscription<DatabaseEvent>? _driverProfileSub;
  StreamSubscription<DatabaseEvent>? _driverRidesSub;
  StreamSubscription<Position>? _positionSub;
  String? _activeFirebaseRideId;
  bool _approved = false;
  bool _blocked = false;
  double _earnings = 0;
  int _completedTrips = 0;
  final Set<String> _ignoredRideIds = <String>{};
  String get _driverId => FirebaseAuth.instance.currentUser?.uid ?? 'anonymous';

  @override
  void initState() {
    super.initState();
    RideHub.instance.activeRide.addListener(_onRideChanged);
    _listenDriverProfile();
    _listenDriverEarnings();
    _listenForFirebaseRequests();
    _setOnlineState(false);
  }
  @override
  void dispose() {
    RideHub.instance.activeRide.removeListener(_onRideChanged);
    _requestsSub?.cancel();
    _driverRideSub?.cancel();
    _driverProfileSub?.cancel();
    _driverRidesSub?.cancel();
    _positionSub?.cancel();
    super.dispose();
  }

  void _listenDriverProfile() {
    _driverProfileSub = _firebase.driverStream(_driverId).listen((event) {
      final raw = event.snapshot.value;
      final data = raw is Map ? Map<String, dynamic>.from(raw) : <String, dynamic>{};
      final approved = data['approved'] == true;
      final blocked = data['blocked'] == true;
      if (!mounted) return;
      setState(() { _approved = approved; _blocked = blocked; });
      if (blocked || !approved) {
        if (online) { setState(() => online = false); _positionSub?.cancel(); _positionSub = null; }
        _setOnlineState(false);
      }
    });
  }

  void _listenDriverEarnings() {
    _driverRidesSub = _firebase.driverRidesStream(_driverId).listen((event) {
      final raw = event.snapshot.value;
      double total = 0; int count = 0;
      if (raw is Map) {
        for (final value in raw.values) {
          if (value is Map && value['status'] == 'completed') {
            final fare = value['fare'];
            if (fare is num) total += fare.toDouble();
            count++;
          }
        }
      }
      if (mounted) setState(() { _earnings = total; _completedTrips = count; });
    });
  }

  void _listenForFirebaseRequests() {
    _requestsSub = _firebase.searchingRidesStream().listen((event) {
      final raw = event.snapshot.value;
      if (raw is! Map) return;
      final entries = raw.entries.toList();
      if (entries.isEmpty || !online || !_approved || _blocked) return;
      final first = entries.first;
      final id = first.key.toString();
      if (_ignoredRideIds.contains(id)) return;
      final data = first.value;
      if (data is! Map) return;
      final pickup = data['pickup'];
      final destination = data['destination'];
      if (pickup is! Map || destination is! Map) return;
      final origin = LatLng((pickup['lat'] as num).toDouble(), (pickup['lng'] as num).toDouble());
      final dest = LatLng((destination['lat'] as num).toDouble(), (destination['lng'] as num).toDouble());
      final ride = RideRequest(
        id: id, origin: origin, destination: dest,
        fareIqd: ((data['fare'] as num?)?.toDouble() ?? 0).round(),
        distanceKm: ((data['distanceKm'] as num?)?.toDouble() ?? 0), etaMinutes: 0,
      );
      _activeFirebaseRideId = id;
      RideHub.instance.createRide(ride);
    });
  }
  void _onRideChanged() { final ride = RideHub.instance.activeRide.value; if (!mounted) return; setState(() { hasRequest = ride != null && ride.status == 'searching'; trip = ride?.status == 'accepted' || ride?.status == 'started'; _passengerLocation = ride?.origin; _destination = ride?.destination; }); }

  Future<void> _setOnlineState(bool value) async {
    if (value && (!_approved || _blocked)) return;
    try {
      await _firebase.setDriverOnline(_driverId, online: value, lat: _myLocation?.latitude, lng: _myLocation?.longitude);
    } catch (_) {}
  }

  Future<void> _startLiveLocation() async {
    await _positionSub?.cancel();
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return;
    _positionSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 10),
    ).listen((p) async {
      final point = LatLng(p.latitude, p.longitude);
      if (!mounted) return;
      setState(() { _myLocation = point; _center = point; });
      try {
        await _firebase.updateDriverLocation(_driverId, p.latitude, p.longitude);
        final rideId = _activeFirebaseRideId;
        if (rideId != null && (RideHub.instance.activeRide.value?.status == 'accepted' || RideHub.instance.activeRide.value?.status == 'started')) {
          await _firebase.updateRideDriverLocation(rideId, p.latitude, p.longitude);
        }
      } catch (_) {}
    });
  }

  Future<void> _locateMe() async {
    setState(() => _locating = true);
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) throw Exception();
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) throw Exception();
      final p = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      final point = LatLng(p.latitude, p.longitude);
      setState(() { _myLocation = point; _center = point; });
      _mapController.move(point, 15.5);
      final ride = RideHub.instance.activeRide.value;
      if (ride != null && (ride.status == 'accepted' || ride.status == 'started')) {
        RideHub.instance.updateDriverLocation(point);
        final id = _activeFirebaseRideId;
        if (id != null) {
          try { await _firebase.updateRideDriverLocation(id, point.latitude, point.longitude); } catch (_) {}
        }
      }
      try { await _firebase.updateDriverLocation(_driverId, point.latitude, point.longitude); } catch (_) {}
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر تحديد موقع السائق.')));
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _showDriverRatingDialog(String rideId) async {
    int selected = 0;
    await showDialog<void>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(
      title: const Text('قيّم الراكب'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('كيف كانت تجربتك مع الراكب؟'),
        const SizedBox(height: 12),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(5, (i) => IconButton(
          onPressed: () => setLocal(() => selected = i + 1),
          icon: Icon(Icons.star, size: 34, color: i < selected ? _yellow : Colors.grey),
        ))),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('لاحقاً')),
        FilledButton(onPressed: selected == 0 ? null : () async {
          try { await _firebase.rateRideByDriver(rideId: rideId, driverId: _driverId, rating: selected); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ تقييم الراكب ⭐'))); } catch (_) {}
          if (dialogContext.mounted) Navigator.pop(dialogContext);
        }, child: const Text('حفظ')),
      ],
    )));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('موتو — السائق'), actions: [IconButton(onPressed: () async { await MotoAuthService().signOut(); if (context.mounted) Navigator.popUntil(context, (r) => r.isFirst); }, icon: const Icon(Icons.logout))]),
        body: Stack(children: [
          _RealMap(mapController: _mapController, center: _center, userLocation: _myLocation, destination: _destination, extraMarkers: _passengerLocation == null ? const [] : [_MapPoint(_passengerLocation!, Icons.person_pin_circle, Colors.green)]),
          Positioned(top: 16, left: 16, right: 16, child: Card(child: SwitchListTile(value: online, onChanged: (!_approved || _blocked) ? null : (v) async {
            setState(() => online = v);
            if (v) { await _startLiveLocation(); } else { await _positionSub?.cancel(); _positionSub = null; }
            try { await _firebase.setDriverOnline(_driverId, online: v, lat: _myLocation?.latitude, lng: _myLocation?.longitude); } catch (_) {}
          }, title: Text(online ? 'متاح للعمل' : 'غير متاح'), subtitle: const Text('استقبال طلبات الرحلات القريبة'), secondary: Icon(Icons.circle, color: online ? Colors.green : Colors.grey)))),
          Positioned(top: 92, right: 16, child: FloatingActionButton.small(heroTag: 'gps-driver', onPressed: _locating ? null : _locateMe, backgroundColor: Colors.white, foregroundColor: Colors.black, child: _locating ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.my_location))),
          Positioned(top: 104, left: 16, child: Card(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('أرباحك: ${_earnings.toStringAsFixed(0)} د.ع', style: const TextStyle(fontWeight: FontWeight.bold)),
            Text('رحلات مكتملة: $_completedTrips', style: const TextStyle(fontSize: 12)),
          ])))), 
          if (!_approved || _blocked) Positioned(bottom: 20, left: 16, right: 16, child: Card(color: _blocked ? Colors.red.shade50 : Colors.orange.shade50, child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
            Icon(_blocked ? Icons.block : Icons.hourglass_top, size: 42, color: _blocked ? Colors.red : Colors.orange),
            const SizedBox(height: 8),
            Text(_blocked ? 'حسابك محظور' : 'بانتظار موافقة الإدارة', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            Text(_blocked ? 'لا يمكن استقبال الرحلات حالياً.' : 'بعد الموافقة تقدر تتحول إلى متاح للعمل.'),
          ])))), 
          if (online && hasRequest && !trip)
            Positioned(bottom: 20, left: 16, right: 16, child: Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('طلب جديد', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              const _LocationRow(icon: Icons.my_location, text: 'موقع الراكب', color: Colors.green),
              const _LocationRow(icon: Icons.location_on, text: 'الوجهة المحددة', color: Colors.red),
              const Divider(),
              const Text('الطلب جاي مباشرة من Firebase ويمكن قبوله من جهاز السائق.'),
              const SizedBox(height: 14),
              Row(children: [Expanded(child: OutlinedButton(onPressed: () { final id = _activeFirebaseRideId; if (id != null) _ignoredRideIds.add(id); _activeFirebaseRideId = null; RideHub.instance.clear(); }, child: const Text('رفض'))), const SizedBox(width: 10), Expanded(child: FilledButton(onPressed: () async {
                final rideId = _activeFirebaseRideId ?? RideHub.instance.activeRide.value?.id;
                if (rideId == null) return;
                try {
                  await _firebase.acceptRide(rideId, _driverId);
                  _driverRideSub?.cancel();
                  _driverRideSub = _firebase.rideStream(rideId).listen((event) {
                    final data = event.snapshot.value;
                    if (data is Map) {
                      final status = (data['status'] ?? 'accepted').toString();
                      final ride = RideHub.instance.activeRide.value;
                      if (ride != null) { ride.status = status == 'in_progress' ? 'started' : status; RideHub.instance.createRide(ride); }
                    }
                  });
                  RideHub.instance.acceptRide(_myLocation ?? _center);
                  await _startLiveLocation();
                } catch (_) {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر قبول الرحلة من Firebase.')));
                }
              }, style: FilledButton.styleFrom(backgroundColor: Colors.green), child: const Text('قبول')))]),
            ]))))
          else if (trip)
            Positioned(bottom: 20, left: 16, right: 16, child: Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
              const Text('طلب مقبول', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('الراكب: متصل الآن • موقعه ظاهر على الخريطة'),
              const SizedBox(height: 14),
              Row(children: [Expanded(child: FilledButton(onPressed: () async { final id = _activeFirebaseRideId; if (id != null) { try { await _firebase.updateRideStatus(id, 'in_progress'); } catch (_) {} } RideHub.instance.startRide(); }, style: FilledButton.styleFrom(backgroundColor: _yellow, foregroundColor: Colors.black), child: const Text('بدء الرحلة'))), const SizedBox(width: 10), Expanded(child: FilledButton(onPressed: () async { final id = _activeFirebaseRideId; if (id != null) { try { await _firebase.updateRideStatus(id, 'completed'); } catch (_) {} } RideHub.instance.finishRide(); if (mounted && id != null) await _showDriverRatingDialog(id); }, style: FilledButton.styleFrom(backgroundColor: Colors.red), child: const Text('إنهاء الرحلة')))]),
            ]))))
          else
            Positioned(bottom: 20, left: 16, right: 16, child: Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: const [Icon(Icons.check_circle_outline, size: 48, color: Colors.green), SizedBox(height: 8), Text('أنت متاح', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text('بانتظار طلبات جديدة...')])))),
        ]),
      ),
    );
  }
}

class _MapPoint { final LatLng point; final IconData icon; final Color color; const _MapPoint(this.point, this.icon, this.color); }

class _RealMap extends StatelessWidget {
  final MapController mapController;
  final LatLng center;
  final LatLng? userLocation;
  final LatLng? destination;
  final RouteResult? route;
  final void Function(TapPosition, LatLng)? onTap;
  final bool selectingDestination;
  final List<_MapPoint> extraMarkers;

  const _RealMap({required this.mapController, required this.center, this.userLocation, this.destination, this.route, this.onTap, this.selectingDestination = false, this.extraMarkers = const []});

  @override
  Widget build(BuildContext context) {
    final markers = <Marker>[];
    if (userLocation != null) markers.add(Marker(point: userLocation!, width: 50, height: 50, child: Container(decoration: BoxDecoration(color: Colors.blue.withOpacity(.16), shape: BoxShape.circle), child: const Icon(Icons.my_location, color: Colors.blue, size: 30))));
    if (destination != null) markers.add(Marker(point: destination!, width: 52, height: 52, child: const Icon(Icons.location_pin, color: Colors.red, size: 48)));
    for (final m in extraMarkers) { markers.add(Marker(point: m.point, width: 52, height: 52, child: Icon(m.icon, color: m.color, size: 42))); }

    return FlutterMap(
      mapController: mapController,
      options: MapOptions(initialCenter: center, initialZoom: 13.5, minZoom: 10, maxZoom: 19, onTap: onTap),
      children: [
        TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.moto.ride'),
        if (route != null && route!.points.length > 1) PolylineLayer(polylines: [Polyline(points: route!.points, strokeWidth: 5, color: Colors.black87)]),
        if (markers.isNotEmpty) MarkerLayer(markers: markers),
        const RichAttributionWidget(attributions: [TextSourceAttribution('© OpenStreetMap contributors')]),
        if (selectingDestination) const Align(alignment: Alignment.topCenter, child: Padding(padding: EdgeInsets.only(top: 112), child: IgnorePointer(child: Card(child: Padding(padding: EdgeInsets.symmetric(horizontal: 14, vertical: 8), child: Text('اضغط على أي مكان بالخريطة', style: TextStyle(fontWeight: FontWeight.bold))))))),
      ],
    );
  }
}

class _NewRideCard extends StatelessWidget {
  final bool selecting;
  final bool searching;
  final bool routingLoading;
  final LatLng? destination;
  final double distanceKm;
  final int fareIqd;
  final int etaMinutes;
  final VoidCallback onSelectDestination;
  final VoidCallback onRequest;

  const _NewRideCard({required this.selecting, required this.searching, required this.routingLoading, required this.destination, required this.distanceKm, required this.fareIqd, required this.etaMinutes, required this.onSelectDestination, required this.onRequest});

  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('رحلة جديدة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const _LocationRow(icon: Icons.my_location, text: 'موقعي الحالي', color: Colors.green),
        _LocationRow(icon: Icons.location_on, text: destination == null ? 'لم تُحدد الوجهة بعد' : 'الوجهة المحددة على الخريطة', color: Colors.red),
        const Divider(height: 24),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('المسافة'), Text(destination == null || routingLoading ? '—' : '${distanceKm.toStringAsFixed(1)} كم', style: const TextStyle(fontWeight: FontWeight.bold)), const Text('ETA'), Text(destination == null || routingLoading ? '—' : '$etaMinutes د', style: const TextStyle(fontWeight: FontWeight.bold))]),
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('الأجرة التقديرية'), Text(destination == null || routingLoading ? '—' : '${_formatIqd(fareIqd)} د.ع', style: const TextStyle(fontWeight: FontWeight.bold))]),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: selecting ? null : onSelectDestination, icon: const Icon(Icons.pin_drop), label: Text(selecting ? 'اختار نقطة من الخريطة...' : 'اختيار الوجهة على الخريطة'))),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: searching || routingLoading || destination == null ? null : onRequest, icon: const Icon(Icons.two_wheeler), label: Text(searching ? 'جاري البحث عن سائق...' : 'اطلب ماطور'), style: FilledButton.styleFrom(backgroundColor: _yellow, foregroundColor: Colors.black, minimumSize: const Size.fromHeight(52)))),
        const SizedBox(height: 6),
        const Text('المسافة والوقت من شبكة الطرق. الأجرة الحالية تجريبية وليست سعراً نهائياً.', style: TextStyle(fontSize: 12, color: Colors.black45)),
      ])));
}

class _TripCard extends StatelessWidget {
  final VoidCallback onFinish;
  final int fare;
  final int etaMinutes;
  const _TripCard({required this.onFinish, required this.fare, required this.etaMinutes});

  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        ListTile(contentPadding: EdgeInsets.zero, leading: const CircleAvatar(backgroundColor: _yellow, child: Icon(Icons.person, color: Colors.black)), title: const Text('علي محمد', style: TextStyle(fontWeight: FontWeight.bold)), subtitle: const Text('Honda 150 • 22-2567'), trailing: Text('$etaMinutes د', style: const TextStyle(fontWeight: FontWeight.bold))),
        const Divider(), const Text('الرحلة جارية', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text('الأجرة: ${_formatIqd(fare)} د.ع'), const SizedBox(height: 10),
        FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red, minimumSize: const Size.fromHeight(48)), onPressed: onFinish, child: const Text('إنهاء الرحلة')),
      ])));
}

class _DriverFoundSheet extends StatelessWidget {
  final VoidCallback onStart;
  final int fare;
  final double distanceKm;
  final int etaMinutes;
  const _DriverFoundSheet({required this.onStart, required this.fare, required this.distanceKm, required this.etaMinutes});

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Padding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 30), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const ListTile(leading: CircleAvatar(radius: 28, backgroundColor: _yellow, child: Icon(Icons.person, color: Colors.black)), title: Text('علي محمد', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), subtitle: Text('Honda 150 • 22-2567'), trailing: Text('4.8 ★')),
        const Divider(), Text('المسافة: ${distanceKm.toStringAsFixed(1)} كم • الوصول المتوقع: $etaMinutes د'), Text('الأجرة التقديرية: ${_formatIqd(fare)} د.ع'),
        const SizedBox(height: 6), const Text('هذا سائق تجريبي. الربط الحقيقي بين الراكب والسائق يأتي مع الخادم.'), const SizedBox(height: 14),
        Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.call), label: const Text('اتصال'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.message), label: const Text('رسالة')))]),
        const SizedBox(height: 10), SizedBox(width: double.infinity, child: FilledButton(onPressed: onStart, style: FilledButton.styleFrom(backgroundColor: _yellow, foregroundColor: Colors.black), child: const Text('بدء الرحلة'))),
      ])));
}

class _LocationRow extends StatelessWidget {
  final IconData icon; final String text; final Color color;
  const _LocationRow({required this.icon, required this.text, required this.color});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [Icon(icon, color: color, size: 22), const SizedBox(width: 10), Expanded(child: Text(text, style: const TextStyle(fontSize: 15)))]));
}

String _formatIqd(int value) {
  final text = value.toString(); final buffer = StringBuffer();
  for (var i = 0; i < text.length; i++) { if (i > 0 && (text.length - i) % 3 == 0) buffer.write(','); buffer.write(text[i]); }
  return buffer.toString();
}
