import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'firebase_service.dart';

class LiveRideController {
  final MotoFirebaseService firebase;
  LiveRideController(this.firebase);

  StreamSubscription<DatabaseEvent>? _rideSub;
  StreamSubscription<DatabaseEvent>? _driverSub;

  Stream<DatabaseEvent> incomingRequests() =>
      firebase.searchingRidesStream();

  Stream<DatabaseEvent> watchRide(String rideId) =>
      firebase.rideStream(rideId);

  Stream<DatabaseEvent> watchDriver(String driverId) =>
      firebase.driverStream(driverId);

  Future<void> accept(String rideId, String driverId) =>
      firebase.acceptRide(rideId, driverId);

  Future<void> finish(String rideId) =>
      firebase.updateRideStatus(rideId, 'completed');

  Future<void> start(String rideId) =>
      firebase.updateRideStatus(rideId, 'in_progress');

  Future<void> cancel(String rideId) =>
      firebase.cancelRide(rideId);

  void dispose() {
    _rideSub?.cancel();
    _driverSub?.cancel();
  }
}
