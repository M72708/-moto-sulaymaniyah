# Moto live rides

v7 adds the Firebase data flows needed for two-device testing:
- passenger creates a ride under `rides/<rideId>`
- driver can stream rides with status `searching`
- driver accepts by setting `status=accepted` and `driverId`
- passenger can stream the accepted ride
- driver location is stored under `drivers/<driverId>/location`
- ride can move to `in_progress`, `completed`, or `cancelled`

The UI still needs to call these methods from the passenger/driver screens.
For production, replace permissive/testing rules with authenticated per-user rules.
