import 'package:firebase_database/firebase_database.dart';

class MotoFirebaseService {
  final FirebaseDatabase db = FirebaseDatabase.instance;
  DatabaseReference get rides => db.ref('rides');
  DatabaseReference get drivers => db.ref('drivers');
  DatabaseReference get users => db.ref('users');

  Future<void> saveUserProfile({required String uid, required String email, required String role}) =>
      users.child(uid).update({'email': email, 'role': role, 'updatedAt': ServerValue.timestamp});

  Future<void> savePassengerProfile({required String uid, required String email, required String name, required String phone}) =>
      users.child(uid).update({'email': email, 'role': 'passenger', 'name': name, 'phone': phone, 'updatedAt': ServerValue.timestamp});

  Stream<DatabaseEvent> userStream(String uid) => users.child(uid).onValue;
  Stream<DatabaseEvent> passengerRidesStream(String uid) => rides.orderByChild('passengerId').equalTo(uid).onValue;
  Stream<DatabaseEvent> pricingStream() => db.ref('settings/pricing').onValue;

  Future<void> rateRide({required String rideId, required String passengerId, required int rating, String? comment}) =>
      rides.child(rideId).update({'passengerRating': rating, 'passengerRatingComment': comment ?? '', 'passengerRatedBy': passengerId, 'passengerRatedAt': ServerValue.timestamp, 'rating': rating});

  Future<void> rateRideByDriver({required String rideId, required String driverId, required int rating, String? comment}) =>
      rides.child(rideId).update({'driverRating': rating, 'driverRatingComment': comment ?? '', 'driverRatedBy': driverId, 'driverRatedAt': ServerValue.timestamp});

  Future<void> saveDriverProfile({required String uid, required String email}) =>
      drivers.child(uid).update({'email': email, 'role': 'driver', 'approved': false, 'blocked': false, 'online': false, 'updatedAt': ServerValue.timestamp});

  Future<void> submitDriverApplication({
    required String uid,
    required String email,
    required String name,
    required String phone,
    required String bike,
    required String plate,
  }) => drivers.child(uid).update({
    'email': email, 'role': 'driver', 'name': name, 'phone': phone,
    'bike': bike, 'plate': plate, 'approved': false, 'blocked': false,
    'online': false, 'applicationStatus': 'pending',
    'submittedAt': ServerValue.timestamp, 'updatedAt': ServerValue.timestamp,
  });

  Future<String> createRide({
    required String passengerId,
    required double pickupLat,
    required double pickupLng,
    required double destinationLat,
    required double destinationLng,
    required double fare,
    required double distanceKm,
  }) async {
    final ref = rides.push();
    await ref.set({
      'passengerId': passengerId,
      'pickup': {'lat': pickupLat, 'lng': pickupLng},
      'destination': {'lat': destinationLat, 'lng': destinationLng},
      'fare': fare,
      'distanceKm': distanceKm,
      'status': 'searching',
      'createdAt': ServerValue.timestamp,
    });
    return ref.key!;
  }

  Stream<DatabaseEvent> rideStream(String rideId) =>
      rides.child(rideId).onValue;

  Future<void> acceptRide(String rideId, String driverId) =>
      rides.child(rideId).update({
        'status': 'accepted',
        'driverId': driverId,
        'acceptedAt': ServerValue.timestamp,
      });

  Future<void> updateRideStatus(String rideId, String status) =>
      rides.child(rideId).update({'status': status, 'updatedAt': ServerValue.timestamp});

  Future<void> updateRideDriverLocation(String rideId, double lat, double lng) =>
      rides.child(rideId).update({
        'driverLocation': {'lat': lat, 'lng': lng},
        'updatedAt': ServerValue.timestamp,
      });


  Future<void> updateDriverLocation(
      String driverId, double lat, double lng) =>
      drivers.child(driverId).update({
        'online': true,
        'location': {'lat': lat, 'lng': lng},
        'updatedAt': ServerValue.timestamp,
      });


  Stream<DatabaseEvent> searchingRidesStream() =>
      rides.orderByChild('status').equalTo('searching').onValue;

  Stream<DatabaseEvent> driverStream(String driverId) =>
      drivers.child(driverId).onValue;

  Stream<DatabaseEvent> driverRidesStream(String driverId) =>
      rides.orderByChild('driverId').equalTo(driverId).onValue;

  Future<void> setDriverOnline(
    String driverId, {
    required bool online,
    double? lat,
    double? lng,
  }) async {
    final data = <String, dynamic>{
      'online': online,
      'updatedAt': ServerValue.timestamp,
    };
    if (lat != null && lng != null) {
      data['location'] = {'lat': lat, 'lng': lng};
    }
    await drivers.child(driverId).update(data);
  }

  Future<void> cancelRide(String rideId) =>
      rides.child(rideId).update({'status': 'cancelled'});

}
