# Moto V31 — فحص ما قبل التشغيل

## الفحص الذي تم داخل بيئة المحادثة
- تم فتح مشروع V30 وفحص بنية ZIP.
- `pubspec.yaml` موجود والإصدار هو `0.3.1+4`.
- `android/app/google-services.json` موجود.
- Package ID الظاهر في إعداد Firebase هو `com.moto.sulaymaniyah` حسب النسخ السابقة للمشروع.
- ملفات Dart الرئيسية موجودة: `main.dart`, `firebase_service.dart`, `admin_dashboard.dart`, `routing_service.dart`.
- قواعد Firebase V29 موجودة.

## نتيجة مهمة
لم يتم تشغيل `flutter analyze` أو بناء APK داخل هذه البيئة لأن Flutter SDK غير مثبت هنا.
لذلك لا نعتبر المشروع "مُختبَر البناء" بعد.

## مسار الاختبار التالي
1. رفع المشروع إلى GitHub.
2. تشغيل GitHub Actions من تبويب Actions.
3. انتظار `Flutter analyze` ثم بناء Debug APK.
4. تنزيل artifact باسم `moto-debug-apk` وتجربته على Android.

## iPhone
المشروع الحالي لا يحتوي مجلد `ios/` كامل في النسخة المفحوصة، لذلك لا ندّعي أن نسخة iPhone جاهزة للبناء بعد. بعد نجاح Android، نجهز مشروع iOS ونضيف إعداد Firebase الخاص بالـ iPhone.
