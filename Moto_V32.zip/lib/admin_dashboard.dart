import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'auth_service.dart';

class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key});
  @override State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}
class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final email = TextEditingController(text: 'admin@moto.iq');
  final password = TextEditingController();
  bool loading = false;
  Future<void> login() async {
    if (email.text.trim().isEmpty || password.text.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب الإيميل وكلمة المرور.'))); return;
    }
    setState(() => loading = true);
    try {
      await MotoAuthService().signIn(email.text, password.text);
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) throw Exception('no-user');
      final snap = await FirebaseDatabase.instance.ref('admins/$uid').get();
      if (snap.value != true) {
        await MotoAuthService().signOut();
        throw Exception('not-admin');
      }
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminDashboard()));
    } catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('هذا الحساب ليس حساب إدارة أو بيانات الدخول غير صحيحة.'))); }
    finally { if (mounted) setState(() => loading = false); }
  }
  @override void dispose(){ email.dispose(); password.dispose(); super.dispose(); }
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:const Text('دخول الإدارة')),body:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Icon(Icons.admin_panel_settings,size:72),const SizedBox(height:16),const Text('لوحة إدارة موتو',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:20),TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'إيميل الإدارة',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'كلمة المرور',border:OutlineInputBorder())),const SizedBox(height:16),SizedBox(width:double.infinity,child:FilledButton(onPressed:loading?null:login,child:Text(loading?'انتظر...':'دخول الإدارة')))]))));
}

class AdminDashboard extends StatefulWidget { const AdminDashboard({super.key}); @override State<AdminDashboard> createState()=>_AdminDashboardState(); }
class _AdminDashboardState extends State<AdminDashboard> {
  final db=FirebaseDatabase.instance;
  StreamSubscription<DatabaseEvent>? ridesSub, driversSub;
  Map<String,dynamic> rideMap={}, driverMap={};
  double baseFare=1000, perKm=500; String status='جاري تحميل البيانات...';
  int get rides=>rideMap.length;
  int get active=>rideMap.values.where((v)=>v is Map && ['searching','accepted','in_progress'].contains(v['status'])).length;
  int get drivers=>driverMap.length;
  int get onlineDrivers=>driverMap.values.where((v)=>v is Map && v['online']==true).length;
  double get totalFare=>rideMap.values.where((v)=>v is Map && v['status']=='completed').fold(0.0,(s,v)=>s+((v['fare'] is num)?(v['fare'] as num).toDouble():0));
  @override void initState(){super.initState();_listen();_loadPricing();}
  void _listen(){
    ridesSub=db.ref('rides').onValue.listen((e){final raw=e.snapshot.value;final m=<String,dynamic>{};if(raw is Map){raw.forEach((k,v){m[k.toString()]=v;});}if(mounted)setState(()=>{rideMap=m,status='متصل'});},onError:(_){if(mounted)setState(()=>status='تأكد من قواعد Firebase');});
    driversSub=db.ref('drivers').onValue.listen((e){final raw=e.snapshot.value;final m=<String,dynamic>{};if(raw is Map){raw.forEach((k,v){m[k.toString()]=v;});}if(mounted)setState(()=>driverMap=m);},onError:(_){ });
  }
  Future<void> _loadPricing() async {final s=await db.ref('settings/pricing').get();final v=s.value;if(v is Map&&mounted)setState((){baseFare=(v['baseFare'] is num)?(v['baseFare'] as num).toDouble():baseFare;perKm=(v['perKm'] is num)?(v['perKm'] as num).toDouble():perKm;});}
  @override void dispose(){ridesSub?.cancel();driversSub?.cancel();super.dispose();}
  Future<void> _setRideStatus(String id,String status) async {await db.ref('rides/$id').update({'status':status,'updatedAt':ServerValue.timestamp});}
  Future<void> _setDriver(String id,Map<String,dynamic> data) async {await db.ref('drivers/$id').update(data);}
  Future<void> _pricingDialog() async {final b=TextEditingController(text:baseFare.toStringAsFixed(0)),k=TextEditingController(text:perKm.toStringAsFixed(0));final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('إعدادات الأسعار'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:b,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'السعر الابتدائي (د.ع)')),TextField(controller:k,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'سعر الكيلومتر (د.ع)'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('حفظ'))]));if(ok==true){final nb=double.tryParse(b.text),nk=double.tryParse(k.text);if(nb!=null&&nk!=null){await db.ref('settings/pricing').set({'baseFare':nb,'perKm':nk,'updatedAt':ServerValue.timestamp});if(mounted)setState((){baseFare=nb;perKm=nk;});}}b.dispose();k.dispose();}
  @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:const Text('لوحة إدارة موتو'),actions:[IconButton(onPressed:_pricingDialog,icon:const Icon(Icons.price_change),tooltip:'الأسعار'),IconButton(onPressed:()async{await MotoAuthService().signOut();if(mounted)Navigator.popUntil(context,(r)=>r.isFirst);},icon:const Icon(Icons.logout))]),body:DefaultTabController(length:3,child:Column(children:[TabBar(tabs:[Tab(icon:Icon(Icons.dashboard),text:'ملخص'),Tab(icon:Icon(Icons.two_wheeler),text:'السائقين'),Tab(icon:Icon(Icons.route),text:'الرحلات')]),Expanded(child:TabBarView(children:[_summary(),_drivers(),_rides()]))])));
  Widget _summary()=>RefreshIndicator(onRefresh:()async{await _loadPricing();setState((){});},child:ListView(padding:const EdgeInsets.all(16),children:[Row(children:[Expanded(child:_stat('الرحلات','$rides',Icons.route)),const SizedBox(width:10),Expanded(child:_stat('النشطة','$active',Icons.sync))]),const SizedBox(height:10),Row(children:[Expanded(child:_stat('السائقين','$drivers',Icons.people)),const SizedBox(width:10),Expanded(child:_stat('أونلاين','$onlineDrivers',Icons.circle))]),const SizedBox(height:10),Card(child:ListTile(leading:const Icon(Icons.payments),title:const Text('إجمالي أجور الرحلات المكتملة'),subtitle:Text('${totalFare.toStringAsFixed(0)} د.ع'))),Card(child:ListTile(leading:const Icon(Icons.price_change),title:const Text('الأسعار الحالية'),subtitle:Text('بداية: ${baseFare.toStringAsFixed(0)} د.ع  •  الكيلومتر: ${perKm.toStringAsFixed(0)} د.ع'),trailing:IconButton(onPressed:_pricingDialog,icon:const Icon(Icons.edit)))),Padding(padding:const EdgeInsets.all(8),child:Text('الحالة: $status',style:const TextStyle(color:Colors.black54)))]));
  Widget _drivers()=>ListView.builder(padding:const EdgeInsets.all(12),itemCount:driverMap.length,itemBuilder:(c,i){final id=driverMap.keys.elementAt(i);final v=driverMap[id];final d=v is Map?Map<String,dynamic>.from(v):<String,dynamic>{};final online=d['online']==true;return Card(child:ListTile(leading:CircleAvatar(child:Icon(online?Icons.circle:Icons.two_wheeler)),title:Text(d['name']?.toString().isNotEmpty==true?d['name'].toString():id),subtitle:Text('ID: $id\n${online?'متصل الآن':'غير متصل'}'),isThreeLine:true,trailing:PopupMenuButton<String>(onSelected:(x)async{if(x=='online')await _setDriver(id,{'online':true});if(x=='offline')await _setDriver(id,{'online':false});if(x=='approve')await _setDriver(id,{'approved':true,'blocked':false,'applicationStatus':'approved'});if(x=='block')await _setDriver(id,{'blocked':true,'approved':false,'online':false,'applicationStatus':'blocked'});if(mounted)setState((){});},itemBuilder:(_)=>const[PopupMenuItem(value:'online',child:Text('تفعيل أونلاين')),PopupMenuItem(value:'offline',child:Text('إيقاف أونلاين')),PopupMenuItem(value:'approve',child:Text('موافقة على السائق')),PopupMenuItem(value:'block',child:Text('حظر السائق'))])));});
  Widget _rides()=>ListView.builder(padding:const EdgeInsets.all(12),itemCount:rideMap.length,itemBuilder:(c,i){final id=rideMap.keys.elementAt(i);final v=rideMap[id];final r=v is Map?Map<String,dynamic>.from(v):<String,dynamic>{};final s=r['status']?.toString()??'غير معروف';final fare=r['fare'];return Card(child:ListTile(leading:Icon(_rideIcon(s)),title:Text('رحلة ${id.length>8?id.substring(0,8):id}'),subtitle:Text('الحالة: $s\nالراكب: ${r['passengerId']??'-'}  •  الأجرة: ${fare??'-'} د.ع\nتقييم السائق: ${r['driverRating']??'-'}/5  •  تقييم الراكب: ${r['passengerRating']??r['rating']??'-'}/5'),isThreeLine:true,trailing:PopupMenuButton<String>(onSelected:(x)async{await _setRideStatus(id,x);},itemBuilder:(_)=>const[PopupMenuItem(value:'searching',child:Text('بحث عن سائق')),PopupMenuItem(value:'accepted',child:Text('تم القبول')),PopupMenuItem(value:'in_progress',child:Text('بدأت الرحلة')),PopupMenuItem(value:'completed',child:Text('إكمال الرحلة')),PopupMenuItem(value:'cancelled',child:Text('إلغاء الرحلة'))])));});
  IconData _rideIcon(String s)=>s=='completed'?Icons.check_circle:s=='cancelled'?Icons.cancel:s=='in_progress'?Icons.directions_bike:s=='accepted'?Icons.person_pin_circle:Icons.search;
  Widget _stat(String t,String v,IconData i)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[Icon(i,size:30),const SizedBox(width:12),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(t,style:const TextStyle(color:Colors.black54)),Text(v,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold))])])));
}
