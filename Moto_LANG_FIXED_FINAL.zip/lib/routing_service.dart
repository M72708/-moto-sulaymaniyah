import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class RouteResult {
  final double distanceMeters;
  final double durationSeconds;
  final List<LatLng> points;

  const RouteResult({
    required this.distanceMeters,
    required this.durationSeconds,
    required this.points,
  });

  double get distanceKm => distanceMeters / 1000.0;
  int get etaMinutes => (durationSeconds / 60).ceil();
}

/// Prototype routing through the public OSRM demo endpoint.
/// It follows the real road network and returns distance, duration and geometry.
/// For a commercial launch, move routing behind your own backend / provider.
class RoutingService {
  static const _base = 'https://router.project-osrm.org/route/v1/driving';

  Future<RouteResult> getRoute(LatLng from, LatLng to) async {
    final coordinates = '${from.longitude},${from.latitude};${to.longitude},${to.latitude}';
    final uri = Uri.parse('$_base/$coordinates?overview=full&geometries=geojson&steps=false');
    final response = await http.get(uri).timeout(const Duration(seconds: 12));

    if (response.statusCode != 200) {
      throw Exception('Routing server error: ${response.statusCode}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (data['code'] != 'Ok') {
      throw Exception(data['message'] ?? 'No route');
    }

    final routes = data['routes'] as List<dynamic>?;
    if (routes == null || routes.isEmpty) throw Exception('No route found');

    final route = routes.first as Map<String, dynamic>;
    final geometry = route['geometry'] as Map<String, dynamic>;
    final rawCoordinates = geometry['coordinates'] as List<dynamic>;

    final points = rawCoordinates.map((item) {
      final pair = item as List<dynamic>;
      return LatLng((pair[1] as num).toDouble(), (pair[0] as num).toDouble());
    }).toList();

    return RouteResult(
      distanceMeters: (route['distance'] as num).toDouble(),
      durationSeconds: (route['duration'] as num).toDouble(),
      points: points,
    );
  }
}
