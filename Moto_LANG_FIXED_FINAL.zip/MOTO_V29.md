# Moto V29

V29 fixes the Firebase Realtime Database rules so the existing app query patterns can work without opening the whole database.

## Included
- Query access for approved drivers to searching rides.
- Query access for passengers to their own rides.
- Query access for drivers to their assigned rides.
- Admin-only collection reads for the admin dashboard.
- `.indexOn` for ride status/passengerId/driverId.
- Passenger rating updates are allowed only on completed rides while core trip fields remain unchanged.
- Driver approval/block values remain protected from self-editing.
- Pricing/settings writes remain admin-only.

## Important
Publish `FIREBASE_RULES_V29.json` in Firebase Realtime Database Rules and test with separate passenger, driver and admin accounts before production use.
