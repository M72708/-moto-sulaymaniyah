Firebase Android configuration added for com.moto.sulaymaniyah.
Realtime Database service scaffold added in lib/firebase_service.dart.
Before production: configure secure Firebase Rules and add iOS GoogleService-Info.plist.
