# Moto V14 — User & Driver Accounts

Next application stage:
- Passenger registration/login using Firebase Authentication.
- Driver registration/login using Firebase Authentication.
- Store profile/role data under Firebase Realtime Database.
- Driver profile fields: name, phone, motorcycle details, verification status.
- Passenger profile fields: name, phone.
- Keep role-based access in the app.
- Do not make Firebase Realtime Database public; authenticated rules are required before production.

Note: this package prepares the project for account integration. The actual Firebase Authentication provider/rules must be enabled in the Firebase project before live sign-in can work.
