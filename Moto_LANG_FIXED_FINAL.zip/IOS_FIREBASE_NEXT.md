# iPhone Firebase setup

The iOS bundle identifier is prepared as:
`com.moto.sulaymaniyah`

One Firebase-generated file is still required for the iPhone build:
`GoogleService-Info.plist`

Create/register the iOS app in Firebase with the bundle ID above, download that file,
and place it in `ios/Runner/GoogleService-Info.plist`.

Do not use the Android `google-services.json` as the iOS file.
