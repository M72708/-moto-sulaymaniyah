# موتو V9 — تنظيف وتجهيز المرحلة التالية

تم إصلاح تكرار `initState` و`dispose` و`_onRideChanged` في شاشة الراكب، والذي كان يمنع ملف `main.dart` من أن يكون Dart صالحاً للترجمة.

## المتبقي قبل تشغيل Firebase فعلياً
1. إنشاء مشروع Flutter كامل بملفات المنصة اللازمة إذا كانت بيئة البناء متاحة.
2. إضافة `Firebase.initializeApp()` و`firebase_options.dart` أو إعداد Firebase الأصلي لكل منصة.
3. إضافة `GoogleService-Info.plist` من Firebase للـ iPhone.
4. ربط واجهة الراكب والسائق بطرق `MotoFirebaseService` بدلاً من `RideHub` المحلي.
5. إعداد Firebase Rules آمنة مع تسجيل دخول المستخدمين.

ملاحظة: `google-services.json` الموجود هو ملف Android فقط، ولا يمكن تحويله إلى `GoogleService-Info.plist`.
