# Moto V33 – Build fixes

- Fixed the async Firebase ride listener in `lib/main.dart`.
- Fixed unbalanced widget parentheses/brackets in `lib/main.dart`.
- Fixed the passenger account/history widget closures.
- Fixed the driver status card widget closures.
- Fixed the admin dashboard `build()` closure.
- Updated GitHub Actions to extract a Moto ZIP automatically when the repository contains the ZIP instead of an extracted Flutter project.

This version is a source/build repair step. It is not a claim of production readiness.
