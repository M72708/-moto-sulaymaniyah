# Moto startup fix

The app no longer creates FirebaseAuth or opens FirebaseAuth.authStateChanges during startup.
Firebase is initialized only after the user presses Login/Create account.
This prevents a Firebase initialization/configuration problem from closing the app immediately.
