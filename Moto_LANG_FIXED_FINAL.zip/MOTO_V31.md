# Moto V31

هذه النسخة تنقل المشروع إلى مرحلة اختبار بناء فعلية عبر GitHub Actions.

## الجديد
- إضافة Workflow لبناء Android Debug APK.
- تشغيل `flutter analyze` قبل البناء.
- رفع APK كـ Artifact باسم `moto-debug-apk`.
- تقرير صريح بحالة الاختبار وعدم الادعاء بأن APK بُني داخل بيئة المحادثة.

## الحالة
- Android: جاهز لمسار CI، لكن لم يُنفذ CI بعد.
- iPhone: يحتاج مجلد ios وإعداد Firebase iOS قبل البناء.
