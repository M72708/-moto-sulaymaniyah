# موتو v0.3 — طلب راكب/سائق حي داخل النسخة التجريبية

هذه النسخة تضيف دورة طلب كاملة داخل نفس تشغيل التطبيق:
- الراكب يحدد الوجهة ويحسب المسار والأجرة.
- عند الضغط على «اطلب ماطور» ينشأ طلب مشترك داخل التطبيق.
- شاشة السائق ترى الطلب وتستطيع قبوله.
- موقع السائق يظهر للواجهة الأخرى بعد القبول عند تحديث GPS.
- السائق يبدأ/ينهي الرحلة.

## مهم
هذا الربط **تجريبي داخل نفس تشغيل التطبيق** وليس بين هاتفين عبر الإنترنت. حتى نربط راكباً وسائقاً على هاتفين مختلفين نحتاج Backend مثل Firebase Realtime Database، الذي يدعم مزامنة البيانات لحظياً بين العملاء. توثيق Firebase يوضح أن Realtime Database يخزن البيانات سحابياً ويزامنها لحظياً، وأن Flutter لديه إضافة رسمية له.

### المرحلة التالية
إنشاء مشروع Firebase، ثم إضافة `firebase_core` و`firebase_database` وتشغيل `flutterfire configure` لإنشاء `firebase_options.dart`. بعد ذلك ننقل RideHub إلى قاعدة البيانات ونضيف Authentication وقواعد أمان.


## V10
This build keeps the Firebase ride-flow scaffold and documents the next passenger/driver integration stage.


## V14
User/driver account integration stage documented in MOTO_V14.md.


## V15
Full trip-flow stage documented in MOTO_V15.md.


## V16
Notifications, final fare, rating, and trip-history stage documented in MOTO_V16.md.


## V17
Admin dashboard structure documented in MOTO_V17.md.

## V18
Firebase Authentication foundation and login gate.


## V19
تمت إضافة لوحة إدارة فعلية داخل `lib/admin_dashboard.dart` مع تسجيل دخول الإدارة وإحصائيات Firebase.


Moto V20: actual admin management UI added (drivers, rides, pricing).


## V21
ربط الحسابات والرحلات بهوية Firebase Auth الحقيقية وإضافة ملفات المستخدم والسائق وتسجيل الخروج.

## V22
تسجيل بيانات السائق وطلب موافقة الإدارة قبل تفعيل استقبال الرحلات.


## V26
تم ربط تسعير الراكب بإعدادات الأسعار الموجودة في Firebase بشكل مباشر.


## V27 — Security hardening
راجع FIREBASE_RULES_V27.json وFIREBASE_ADMIN_SETUP_V27.md قبل النشر.


## V29
Firebase query/security rules were updated for passenger/driver ride queries and ratings. Use FIREBASE_RULES_V29.json.

## V31
تمت إضافة GitHub Actions لبناء Android Debug APK وتشغيل flutter analyze قبل البناء. راجع TEST_REPORT_V31.md.

## V32
تم تصحيح مسار بناء Android: ملف المشروع لا يحتوي منصة Android كاملة داخل ZIP، لذلك GitHub Actions الآن ينشئ ملفات Android باستخدام Flutter نفسه قبل `pub get` و`analyze` و`build`. كما يضبط package ID إلى `com.moto.sulaymaniyah` ويضيف Google Services لملف Firebase الموجود.

**مهم:** هذا لا يعني أن APK تم بناؤه هنا؛ البناء الفعلي يتم داخل GitHub Actions بعد رفع المشروع وتشغيل الـ workflow.
