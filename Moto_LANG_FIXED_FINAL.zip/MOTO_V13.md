# Moto V13

- Passenger and driver Firebase ride flow retained.
- Driver live GPS stream now publishes driver location to Firebase while online.
- During an accepted/in-progress ride, driver location is also written into the ride record so the passenger can see movement.
- Passenger UI shows a motorcycle marker from the current ride's driver location.
- Driver rejection is local for this demo, so it does not cancel the passenger's ride for every driver.
- iOS Firebase plist is intentionally not fabricated; it must come from the user's Firebase project.
